export const environment = {
  production: true,
   ICSAUrl:"http://162.216.193.122:8106/api/v1/"
};
