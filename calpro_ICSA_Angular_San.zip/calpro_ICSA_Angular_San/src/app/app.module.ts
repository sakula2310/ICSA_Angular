import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from "@angular/common";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './common/header/header.component';
import { FooterComponent } from './common/footer/footer.component';
import { LoginComponent } from './common/login/login.component';
import { RegisterComponent } from './common/register/register.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { ReportviewerDashboardComponent } from './reportviewer-dashboard/reportviewer-dashboard.component';
import { MyprofileComponent } from './myprofile/myprofile.component';
import { AddEditUserComponent } from './add-edit-user/add-edit-user.component';
import { ApiService } from './services/common/api.service';
import { LoginService } from './services/ICSA/login.service';
import { ReportService } from './services/ICSA/report.service';
import { ChartsModule } from 'ng2-charts';
import { HTTP_INTERCEPTORS, HttpClientModule } from "@angular/common/http";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { PasswordPatternDirective } from './directives/password-pattern.directive';
import { MatchPasswordDirective } from './directives/match-password.directive';
import { MatListModule } from '@angular/material/list';
import { MasterService } from './services/ICSA/master.service';
import { SampleWizardComponent } from './sample-wizard/sample-wizard.component';
import { QuestionheaderComponent } from './common/questionheader/questionheader.component';
import { SharedService } from './services/ICSA/shared.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CompetencyService } from './services/ICSA/competency.service';
 import {  MatRadioModule } from '@angular/material/radio';
import { TooltipComponent } from './common/tooltip/tooltip.component';
import { TooltipModule } from 'ng2-tooltip-directive';
import { MatDialogModule } from '@angular/material/dialog';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgxSpinnerModule } from 'ngx-spinner';
import { IcsaInterceptor } from './services/common/icsa.interceptor';
import { SideNavComponent } from './side-nav/side-nav.component';
import { StorageService } from './services/common/stoarge.service';
import { PrioritizeComperencyComponent } from './prioritize-comperency/prioritize-comperency.component';
import { PrintSaveAllCompetenciesComponent } from './print-save-all-competencies/print-save-all-competencies.component';
import { PrintSaveTopFiveCompetenciesComponent } from './print-save-top-five-competencies/print-save-top-five-competencies.component';
import { TopFiveProfessionalDevelopmentResourcePlansComponent } from './top-five-professional-development-resource-plans/top-five-professional-development-resource-plans.component';
import { PdpPlanResourceComponent } from './pdp-plan-resource/pdp-plan-resource.component';
import { ViewAssessmentResultsComponent } from './view-assessment-results/view-assessment-results.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    PrintSaveAllCompetenciesComponent,
    PrintSaveTopFiveCompetenciesComponent,
    TopFiveProfessionalDevelopmentResourcePlansComponent,
    ViewAssessmentResultsComponent,
    PdpPlanResourceComponent,
    LoginComponent,
    RegisterComponent,
    AdminDashboardComponent,
    UserDashboardComponent,
    ReportviewerDashboardComponent,
    MyprofileComponent,
    AddEditUserComponent,
    PasswordPatternDirective,
    MatchPasswordDirective,
    SampleWizardComponent,
    QuestionheaderComponent,
    TooltipComponent,
    SideNavComponent,
    PrioritizeComperencyComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    MatListModule,
    FormsModule,
    AppRoutingModule,
    ChartsModule, 
    HttpClientModule,
    BrowserAnimationsModule,
    NgbModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    ReactiveFormsModule,
    NgbModule,
    MatRadioModule,
    TooltipModule,
    MatDialogModule,
    NgMultiSelectDropDownModule.forRoot(),
    NgxSpinnerModule
  
  ],
 
  providers: [ApiService, LoginService, ReportService, MasterService, SharedService,CompetencyService, StorageService,
    { provide: HTTP_INTERCEPTORS, useClass: IcsaInterceptor, multi: true },],
  bootstrap: [AppComponent],
    entryComponents: [TooltipComponent]

})
export class AppModule { }
