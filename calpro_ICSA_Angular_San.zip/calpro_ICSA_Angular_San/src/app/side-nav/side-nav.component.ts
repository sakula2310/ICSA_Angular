import { Component, OnInit, OnChanges } from '@angular/core';
import { Router,NavigationStart, Event as NavigationEvent } from '@angular/router';
import { Subscription } from 'rxjs';
import { LoginService } from 'src/app/services/ICSA/login.service';
import { SharedService } from 'src/app/services/ICSA/shared.service';
import { StorageService } from '../services/common/stoarge.service';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.css']
})
export class SideNavComponent implements OnInit, OnChanges {

  isShow: boolean = false;
  isEnableMenu: boolean = false;
  currentUser: any;
  headername: any;
  currentAssessment: any;
  currentUserSubscription: Subscription;
  currenturl='';
  users: any[] = [];
  constructor(private service: LoginService, private route: Router,
    private shared: SharedService, private dataSe: StorageService) {
      this.route.events
      .subscribe(
        (event: NavigationEvent) => {
          if(event instanceof NavigationStart) {
            console.log(event.url);
            this.currenturl=event.url;
          }
        });
  }

  ngOnInit() {

    this.shared.title.subscribe(value => this.headername = value);
    this.shared.isMenuVisible.subscribe(value => this.isShow = value);

      this.shared.isEnableMenuOptions.subscribe(value => this.isEnableMenu = value);


  }
  ngOnChanges() {
    this.shared.isMenuVisible.subscribe(value => this.isShow = value);
    this.shared.isEnableMenuOptions.subscribe(value => this.isEnableMenu = value);
  }
}
