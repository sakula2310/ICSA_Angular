export class QuestionResponse {
   public optionOneText: any;
   public optionTwoText: any;
   public optionThreeText: any;
   public questionId: number;
}
