export class PriorityLevel {
    totalScore:         number;
    competencyArea:     number;
    priorityLevel:      null;
    totalScoreInWords:  string;
    priorityOpationList: PriorityOpationList[];
    questionId:         number;
    questionText:       string;
}
export class PriorityOpationList {
    id:         number;
    text:       string;
    questionId: number;
}

export class SeletedPriorityOptions{
    priorityLevel?:         number;
    optionText:       string;
    questionId: number;
}

