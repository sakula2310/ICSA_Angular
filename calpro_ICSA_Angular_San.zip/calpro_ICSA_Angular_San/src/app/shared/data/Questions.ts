export interface Questions {
    optionsList1:   OptionsList[];
    optionsList2:   OptionsList[];
    optionsList3:   OptionsList[];
    quesIndicaters: QuesIndicater[];
    illustrations:  Illustration[];
    questionId:     number;
    questionText:   string;
    option1:        null;
    option2:        null;
    option3:        null;
}

export interface Illustration {
    questionId:           number;
    subQuestionTypeId:    null;
    illustrationId:       number;
    illustrationIndex:    number;
    illustrationText:     string;
    illustrationTypeId:   number;
    illustrationTypeText: string;
}

export interface OptionsList {
    optionId:  number;
    isChecked: boolean;
    isAns:     boolean;
}

export interface QuesIndicater {
    questionId:        number;
    subQuestionTypeId: null;
    indicatorId:       number;
    indicatorIndex:    number;
    indicatorText:     string;
    indicatorTypeId:   number;
    indicatorTypeText: string;
}