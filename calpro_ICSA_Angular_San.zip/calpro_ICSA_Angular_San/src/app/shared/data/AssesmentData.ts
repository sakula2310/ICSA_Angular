export class Assesment {
    public assessmentId: number;
    public assessmentName: string;
    public userId: number;
    public assessmentStartDate: string;
    public assessmentEndDate: string;
    public completedCompetency: number;
    public assessmentStatus: string;
    public competencyStatus1: boolean;
    public competencyStatus2: boolean;
    public competencyStatus3: boolean;
    public competencyStatus4: boolean;    
    public completedCompetencyinWords: string;
    public competencyinWords: string;
}
