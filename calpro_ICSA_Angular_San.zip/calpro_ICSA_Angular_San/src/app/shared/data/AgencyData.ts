export class Agency{
   public codeId: number;
   public countryName: string;
   public ncs: string;
   public type: string;
   public agencyName: string;
   public orderBy: number;
}
