export class AssessmentResponse {
    public  totalScore: Number;
    public  competencyArea: Number;
    public  PriorityLevel: Number;
    public  area: Number;
    public  totalScoreInWords: string;
    public  questionText: string;
    public  questionId: string;
    public  competencyTypeName: string;
    public  competencyTypeId: Number;
    public  scoringLanguageDescription: string;
}

export class PDResourcePlans {
    public calproPDRPlanDescription: any[];
    public otherPDRPlanDescription: any[];
    public questionName: string;
    public rankingValue: string;
    public competencyNumber: string;
}
