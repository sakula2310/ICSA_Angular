export enum enumPriority {
  "data"=1,   // VERY LOW
  "instruction" = 2,    // LOW
  "communicates" = 3,    // NORMAL
  "professionalism" = 4,    // HIGH
}

