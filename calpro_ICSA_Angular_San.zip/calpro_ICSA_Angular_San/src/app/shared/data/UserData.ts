export class User {
    public userId: number;
    public firstName: string;
    public lastName: string;
    public email: string;
    public password: string;
    public confirmPassword: string;
    public agencyCodeId: number;
    public termsofUseId: number;
    public agencyIds: string;
    public agencies: any[];
    public role: number;
    public roleName: string;
}