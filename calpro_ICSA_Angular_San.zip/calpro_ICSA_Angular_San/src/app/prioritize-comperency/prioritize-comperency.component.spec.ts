import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrioritizeComperencyComponent } from './prioritize-comperency.component';

describe('PrioritizeComperencyComponent', () => {
  let component: PrioritizeComperencyComponent;
  let fixture: ComponentFixture<PrioritizeComperencyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrioritizeComperencyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrioritizeComperencyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
