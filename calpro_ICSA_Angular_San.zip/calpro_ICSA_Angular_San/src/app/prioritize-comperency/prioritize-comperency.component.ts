import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { delay } from 'rxjs/Operators';
import { CompetencyService } from '../services/ICSA/competency.service';
import { SharedService } from '../services/ICSA/shared.service';
import { enumPriority } from '../shared/data/EnumPriorty';
import { PriorityLevel, PriorityOpationList, SeletedPriorityOptions } from '../shared/data/Priority';

@Component({
  selector: 'app-prioritize-comperency',
  templateUrl: './prioritize-comperency.component.html',
  styleUrls: ['./prioritize-comperency.component.css']
})
export class PrioritizeComperencyComponent implements OnInit {
 userId: number;
  assessmentId: number;
  priorityLst: PriorityLevel[]=[];
  selPriority: SeletedPriorityOptions= new SeletedPriorityOptions();
  selPriorityList: SeletedPriorityOptions[] = [];

  constructor(private service: CompetencyService, private activatedRoute: ActivatedRoute, private route: Router, public dialog: MatDialog
    , private shared: SharedService,) {
    var currentUserData = JSON.parse(localStorage.getItem('currentUser'));
    this.userId = currentUserData["userId"];
  }
  ngOnInit() {
     
    alert('\n \nYour selections resulted in more than five high-ranking competencies, some of which are similarly ranked. In order to create a manageable professional development plan that you can accomplish within a year, CALPRO recommends that you further prioritize your list of areas of concentration by ranking your top five 1 to 5 and leaving “Select” as the choice on other items, if any')

     this.activatedRoute.paramMap.subscribe(params => {
       if (params.get("id") != null) {
         this.shared.enableMenuOptions(false);
         this.assessmentId = Number(params.get("id"));
       }
    });
   this.getPrioritizeLevel();
  }
  getPrioritizeLevel() {
    this.service.getPrioritizeLevel(this.userId, this.assessmentId).subscribe(data => {
      console.log(data);
      this.priorityLst = data;
      data.forEach(e => {
        if (e.priorityLevel !== null) {
          var obj = {
            optionText: e.priorityLevel,
            priorityLevel: (e.priorityLevel == null) ? null : Number(e.priorityLevel),
            questionId: e.questionId
          }
          this.selPriorityList.push(obj);
        }
      });
    });
  }
  SavePriority() {
    let unique = this.selPriorityList.filter((set => f => !set.has(f.priorityLevel) && set.add(f.priorityLevel))(new Set));
    unique = unique.filter(x => x.priorityLevel !== null);
    this.selPriorityList= this.selPriorityList.filter(x => x.priorityLevel !== null);

    if (unique.length !== this.selPriorityList.length) {
      alert('duplicate values');
    } else {
      var reqItem = {
        userId: this.userId,
        assessmentId: this.assessmentId,
        priorityLists: this.selPriorityList
      }

      this.service.savePrioritizeLevel(reqItem).subscribe(data => {
        console.log(data);
        let competency = Number(JSON.parse(localStorage.getItem("nextComptencyId")));
        if (competency === 5) {
           this.route.navigate(["/userdashboard"]);
        } else {
          this.shared.enableMenuOptions(true);
          this.route.navigate(["/wizard", enumPriority[competency].toString()]);
        }
        });
    }
  }
  
  priorityChange(itemrow, item) {
    debugger;
    console.log(item);
    console.log(itemrow);
    this.selPriority = { optionText:(item==-1)? null:item, priorityLevel: (item==-1)?null: Number(item), questionId: itemrow.questionId };

   for( var i = 0; i < this.selPriorityList.length; i++){ 
                                   
        if ( this.selPriorityList[i].questionId === this.selPriority.questionId) { 
             this.selPriorityList.splice(i, 1); 
            i--; 
        }
   }
    this.selPriorityList.push(this.selPriority);
  }
}

 
