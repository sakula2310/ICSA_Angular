import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CompetencyService } from '../services/ICSA/competency.service';
import { PDResourcePlans } from '../shared/data/AssessmentResponse';
import * as pdfMake from "pdfmake/build/pdfmake";
import * as pdfFonts from "pdfmake/build/vfs_fonts";
(pdfMake as any).vfs = pdfFonts.pdfMake.vfs;
import htmlToPdfmake from 'html-to-pdfmake';

@Component({
  selector: 'app-pdp-plan-resource',
  templateUrl: './pdp-plan-resource.component.html',
  styleUrls: ['./pdp-plan-resource.component.css']
})
export class PdpPlanResourceComponent implements OnInit {
loggedinUser: string;
loggedinUserID: number;
selectedAssesmentId: number;
pdResourcePlans :PDResourcePlans[];
@ViewChild('pdfTable', {static: false}) pdfTable: ElementRef;

 constructor(private csservice: CompetencyService,private route: ActivatedRoute) { }

 ngOnInit(): void {
   this.pdResourcePlans =[];
   var currentUserData = JSON.parse(localStorage.getItem('currentUser'));
   this.loggedinUser = currentUserData["firstName"];
   this.loggedinUserID = currentUserData["userId"];
   this.route.paramMap.subscribe(params => {
     const questionid = params.get('questionid');
     const rank = params.get('rank');
     var id = parseInt(questionid);
     var rankid = parseInt(rank);
     if ((id != null || id != 0) && (rankid !=null|| rankid!=0)) {
      this.GetPDResponse(questionid,rank);
     }
   });
 }
 GetPDResponse(questionid,rank) {
   if (this.loggedinUserID > 0) {
     this.csservice.GetPDResponse(questionid,rank).subscribe(data => {
      this.pdResourcePlans = data;
       console.log(data);
     });
   }
 }
 onPrint(){
    
  //   const doc = new jsPDF('p', 'pt', 'letter');

    

  //  const elementToPrint = document.getElementById('pdfTable'); //The html element to become a pdf
  //  const margins = {
  //   top: 80,
  //   bottom: 60,
  //   left: 40,
  //   width: 522
  // };



  // // or
  
  // doc.fromHTML(elementToPrint.innerHTML, margins.left, margins.top, {}, function () {

  //   doc.save("Topfive.pdf");
  // }, margins);
   debugger;
  const pdfTable = this.pdfTable.nativeElement;
 
  var html = htmlToPdfmake(pdfTable.innerHTML);
   
  const documentDefinition = { content: html };
  pdfMake.createPdf(documentDefinition).download();

//   doc.addHTML(html, function() {
//     doc.save("obrz.pdf");
//  });
}
}


