import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PdpPlanResourceComponent } from './pdp-plan-resource.component';

describe('PdpPlanResourceComponent', () => {
  let component: PdpPlanResourceComponent;
  let fixture: ComponentFixture<PdpPlanResourceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PdpPlanResourceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PdpPlanResourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
