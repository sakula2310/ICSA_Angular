import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CompetencyService } from '../services/ICSA/competency.service';
import { AssessmentResponse } from '../shared/data/AssessmentResponse';
import jsPDF from 'jspdf';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;
import htmlToPdfmake from 'html-to-pdfmake';
@Component({
  selector: 'app-view-assessment-results',
  templateUrl: './view-assessment-results.component.html',
  styleUrls: ['./view-assessment-results.component.css']
})
export class ViewAssessmentResultsComponent implements OnInit {
  page = 1;
  pageSize = 6;
  collectionSize = 0;
  assessmentResponsedata: AssessmentResponse[];
  assessmentResponsedatalst: AssessmentResponse[];
  loggedinUser: string;
  loggedinUserID: number;
  selectedAssesmentId: number;
  isVisible: boolean = false;
  assmentid: any;
  defaultview: boolean = true;
  competencyTypeOneList: AssessmentResponse[];
  competencyTypeTwoList: AssessmentResponse[];
  competencyTypeThreeList: AssessmentResponse[];
  competencyTypeFourList: AssessmentResponse[];
  competencyTypeAllList:AssessmentResponse[];
  isPDPriority:boolean =false;
  isnotdefault:boolean =false;
  constructor(private csservice: CompetencyService, private route: ActivatedRoute) {
    this.assessmentResponsedatalst = [];
  }
  ngOnInit(): void {
    this.competencyTypeOneList = [];
    this.competencyTypeTwoList = [];
    this.competencyTypeThreeList = [];
    this.competencyTypeFourList = [];
    this.competencyTypeAllList=[];
    this.assessmentResponsedatalst = [];
    var currentUserData = JSON.parse(localStorage.getItem('currentUser'));
    this.loggedinUser = currentUserData["firstName"];
    this.loggedinUserID = currentUserData["userId"];
    this.route.paramMap.subscribe(params => {
      const assesmentid = params.get('assesmentid');
      var id = parseInt(assesmentid);
      if (id != null || id != 0) {
        this.assmentid = assesmentid;
        this.getPDPriorityData();
      }
    });
  }
  GetUserAssesmentsbyUser() {

    if (this.loggedinUserID > 0) {
      this.csservice.GetTopFiveAssessmentResponse(this.loggedinUserID, this.assmentid).subscribe(data => {
        this.assessmentResponsedata = data;
        this.assessmentResponsedatalst = this.assessmentResponsedata.sort(function (a, b) {
          return parseInt(a.questionId) - parseInt(b.questionId);
        });
        this.isVisible = false;
      });
    }
  }
  GetLowerRankData() {
    this.defaultview = false;
    this.isPDPriority= false;
    this.competencyTypeTwoList =[];
    this.competencyTypeOneList =[];
    this.competencyTypeTwoList =[];
    this.competencyTypeThreeList =[];
    this.competencyTypeFourList =[];
    this.competencyTypeAllList =[];
    this.GetUserAssesmentsbyUserOrder();
  }
  Displayorderbycompetency(pdPriority)
  {
    if(pdPriority ==1)
    {
      this.isnotdefault= false;
      this.isPDPriority= true;
      this.competencyTypeAllList = this.competencyTypeAllList.sort(function (a, b) {
        return 0 - (parseInt(a.area.toString()) > parseInt(b.area.toString()) ? 1 : -1) ;
      });
    }
    else{
      this.isnotdefault= true;
      this.isPDPriority =false;
      this.competencyTypeOneList = this.competencyTypeOneList.sort(function (a, b) {
        return parseInt(a.questionId) - parseInt(b.questionId);
      });
      this.competencyTypeTwoList = this.competencyTypeTwoList.sort(function (a, b) {
        return parseInt(a.questionId) - parseInt(b.questionId);
      });
      this.competencyTypeThreeList = this.competencyTypeThreeList.sort(function (a, b) {
        return parseInt(a.questionId) - parseInt(b.questionId);
      });
      this.competencyTypeFourList = this.competencyTypeFourList.sort(function (a, b) {
        return parseInt(a.questionId) - parseInt(b.questionId);
      });

    }
  }
  GetUserAssesmentsbyUserOrder() {
    if (this.loggedinUserID > 0) {
      this.csservice.GetAssessmentResponse(this.loggedinUserID, this.assmentid).subscribe(data => {
        this.assessmentResponsedata = data;
        this.assessmentResponsedatalst = this.assessmentResponsedata
        console.log(data);
        this.competencyTypeAllList = this.assessmentResponsedatalst.sort(function (a, b) {
          return parseInt(a.area.toString()) - parseInt(b.area.toString());
        });
        
        for (let i = 0; i < this.competencyTypeAllList.length; i++) {
          if (data[i].competencyTypeId === 1) {
            this.competencyTypeOneList.push(this.competencyTypeAllList[i]);
          }
          else if (this.competencyTypeAllList[i].competencyTypeId === 2) {
            this.competencyTypeTwoList.push(this.competencyTypeAllList[i]);
          }
          else if (this.competencyTypeAllList[i].competencyTypeId === 3) {
            this.competencyTypeThreeList.push(this.competencyTypeAllList[i]);
          }
          else if (this.competencyTypeAllList[i].competencyTypeId === 4) {
            this.competencyTypeFourList.push(this.competencyTypeAllList[i]);
          }
        }
      });
    }
  }

  getPDPriorityData() {
    this.defaultview = true;
    if (this.loggedinUserID > 0) {
      this.csservice.GetTopFiveAssessmentResponse(this.loggedinUserID, this.assmentid).subscribe(data => {
        this.assessmentResponsedata = data;
        this.assessmentResponsedatalst = this.assessmentResponsedata;
        this.isVisible = true;
      });
    }

  }

  onSort(event) {
  }
  refreshdata() {
    this.assessmentResponsedatalst = this.assessmentResponsedata
      .map((user, i) => ({ id: i + 1, ...user }))
      .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }

  onPrint() {
    // const doc = new jsPDF();
   
    // const pdfTable = this.pdfTable.nativeElement;
   
    // var html = htmlToPdfmake(pdfTable.innerHTML);
     
    // const documentDefinition = { content: html };
    // pdfMake.createPdf(documentDefinition).open(); 
  }

}