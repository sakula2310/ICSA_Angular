import { Component, OnInit, OnChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { LoginService } from 'src/app/services/ICSA/login.service';
import { SharedService } from 'src/app/services/ICSA/shared.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnChanges {
  title = 'ICSA';
  isShow: boolean = false;
  currentUser: any;
  headername: any;
  currentUserSubscription: Subscription;
  users: any[] = [];
  constructor(private service: LoginService, private route: Router, private aRouter: ActivatedRoute, private shared: SharedService) {
  }

  ngOnInit(): void {
    this.shared.title.subscribe(value => this.headername = value);
    this.currentUserSubscription = this.service.currentUserSubject.subscribe(user => {
      this.currentUser = user;
      if (this.currentUser != null) {
        if (this.currentUser.roleId == 1) {
          this.shared.setMenuVisibility(true);
          this.isShow = true;
        }
      }

    });
  }
  ngOnChanges() {
    this.shared.isMenuVisible.subscribe(value => this.isShow = value);
  }

}
