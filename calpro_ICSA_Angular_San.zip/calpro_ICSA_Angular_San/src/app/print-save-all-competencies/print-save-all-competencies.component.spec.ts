import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintSaveAllCompetenciesComponent } from './print-save-all-competencies.component';

describe('PrintSaveAllCompetenciesComponent', () => {
  let component: PrintSaveAllCompetenciesComponent;
  let fixture: ComponentFixture<PrintSaveAllCompetenciesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrintSaveAllCompetenciesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrintSaveAllCompetenciesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
