import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { LoginService } from '../services/ICSA/login.service';
import { MasterService } from '../services/ICSA/master.service';
import { SharedService } from '../services/ICSA/shared.service';
import { Agency } from '../shared/data/AgencyData';
import { User } from '../shared/data/UserData';

@Component({
  selector: 'app-myprofile',
  templateUrl: './myprofile.component.html',
  styleUrls: ['./myprofile.component.css']
})
export class MyprofileComponent implements OnInit {
  currentUser: any;
  currentUserSubscription: Subscription;
  user: User = new User();
  agencyList: Agency[];
  roleList: any;
  validateAgency: boolean;
  selectedAgencies: any;
  dropdownSettings: any = {};
  showSuccess: boolean;

  constructor(private master: MasterService, private shared: SharedService, private loginService: LoginService, private route: Router) { }

  ngOnInit(): void {
    this.showSuccess = false;
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'codeId',
      textField: 'agencyName',
      selectAllText: 'select All',
      unSelectAllText: 'Unselect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
    this.shared.setTitle("My Profile");
    this.shared.setMenuVisibility(false);
    this.currentUserSubscription = this.loginService.currentUser.subscribe(user => {
      this.currentUser = user;
      // if (this.currentUser != null) {
      //   this.currentUser.userId
      // }
      // else {
      // }
    });

    this.loadAgencyList();


  }

  loadAgencyList() {
    this.master.getAgencies().subscribe(data => {
      this.agencyList = data;
      this.loadUserDetails(this.currentUser.userId);
    });
  }
  loadUserDetails(userId) {
    this.loginService.getUserInfoByUserId(userId).subscribe(data => {
      var userDetails = data.result;
      if (userDetails) {

        this.user.email = userDetails.userEmailId;
        this.user.firstName = userDetails.firstName;
        this.user.lastName = userDetails.lastName;
        this.loginService.getAgenciesByUserId(userId).subscribe(agencies => {
          if (agencies.result) {
            this.user.agencies = agencies.result;
          }
        });
      }
    });
  }

  updateUser() {
    this.showSuccess = false;
    this.validateAgency = false;
    if (this.user.agencies.length > 0) {
      this.user.agencyIds = this.user.agencies.map(x => x.codeId).join(",");
      this.user.userId = this.currentUser.userId;
      this.loginService.updateUserDetails(this.user).subscribe(data => {
        if (data.includes("success")) {
          this.currentUser.firstName = this.user.firstName;
          this.currentUser.lastName = this.user.lastName;
          this.showSuccess = true;
        }
      });
    }
    else {
      this.validateAgency = true;
    }
  }
  navigateToDashboard() {
    this.showSuccess = false;
    if (this.currentUser.roleId == 2) {
      this.route.navigate(["/admindashboard"]);
    }
    else if (this.currentUser.roleId == 3) {
      this.route.navigate(["/reviewerdashboard"]);
    }
    else {
      this.route.navigate(["/userdashboard"]);
      this.shared.setMenuVisibility(true);
    }
  }
}
