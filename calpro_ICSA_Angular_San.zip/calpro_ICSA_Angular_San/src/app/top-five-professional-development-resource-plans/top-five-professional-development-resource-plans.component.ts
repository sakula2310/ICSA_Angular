import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CompetencyService } from '../services/ICSA/competency.service';
import { PDResourcePlans } from '../shared/data/AssessmentResponse';
import html2canvas from 'html2canvas'; 
import jsPDF from 'jspdf';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;
import htmlToPdfmake from 'html-to-pdfmake';
@Component({
  selector: 'app-top-five-professional-development-resource-plans',
  templateUrl: './top-five-professional-development-resource-plans.component.html',
  styleUrls: ['./top-five-professional-development-resource-plans.component.css']
})
export class TopFiveProfessionalDevelopmentResourcePlansComponent implements OnInit {
   loggedinUser: string;
   loggedinUserID: number;
   selectedAssesmentId: number;
   pdResourcePlans :PDResourcePlans[];
   @ViewChild('pdfTable', {static: false}) pdfTable: ElementRef;

  constructor(private csservice: CompetencyService,private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.pdResourcePlans =[];
    var currentUserData = JSON.parse(localStorage.getItem('currentUser'));
    this.loggedinUser = currentUserData["firstName"];
    this.loggedinUserID = currentUserData["userId"];
    this.route.paramMap.subscribe(params => {
      const assesmentid = params.get('assesmentid');
      var id = parseInt(assesmentid);
      if (id != null || id != 0) {
       this.GetUserAssesmentsbyUser(assesmentid);
      }
    });
  }
  GetUserAssesmentsbyUser(assesmentid) {
    if (this.loggedinUserID > 0) {
      this.csservice.GetTopFiveProfessionalDevelopmentResourcePlans(this.loggedinUserID,assesmentid).subscribe(data => {
       this.pdResourcePlans = data;
        console.log(data);
      });
    }
  }
  onPrint(){
    debugger;

    

    const pdfTable = this.pdfTable.nativeElement;
 
  var html = htmlToPdfmake(pdfTable.innerHTML);
   
  const documentDefinition = { content: html };
  pdfMake.createPdf(documentDefinition).download();
  // or
  
  // doc.fromHTML(elementToPrint.innerHTML, margins.left, margins.top, {}, function () {

  //   doc.save("Topfive.pdf");
  // }, margins);

}
    
}


