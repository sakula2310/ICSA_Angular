import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TopFiveProfessionalDevelopmentResourcePlansComponent } from './top-five-professional-development-resource-plans.component';

describe('TopFiveProfessionalDevelopmentResourcePlansComponent', () => {
  let component: TopFiveProfessionalDevelopmentResourcePlansComponent;
  let fixture: ComponentFixture<TopFiveProfessionalDevelopmentResourcePlansComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TopFiveProfessionalDevelopmentResourcePlansComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TopFiveProfessionalDevelopmentResourcePlansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
