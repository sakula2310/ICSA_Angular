import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintSaveTopFiveCompetenciesComponent } from './print-save-top-five-competencies.component';

describe('PrintSaveTopFiveCompetenciesComponent', () => {
  let component: PrintSaveTopFiveCompetenciesComponent;
  let fixture: ComponentFixture<PrintSaveTopFiveCompetenciesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrintSaveTopFiveCompetenciesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrintSaveTopFiveCompetenciesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
