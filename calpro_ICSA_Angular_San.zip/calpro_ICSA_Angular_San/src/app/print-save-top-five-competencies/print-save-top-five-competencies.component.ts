import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CompetencyService } from '../services/ICSA/competency.service';
import { AssessmentResponse } from '../shared/data/AssessmentResponse';
import * as pdfMake from "pdfmake/build/pdfmake";
import * as pdfFonts from "pdfmake/build/vfs_fonts";
(pdfMake as any).vfs = pdfFonts.pdfMake.vfs;

import htmlToPdfmake from 'html-to-pdfmake';
@Component({
  selector: 'app-print-save-top-five-competencies',
  templateUrl: './print-save-top-five-competencies.component.html',
  styleUrls: ['./print-save-top-five-competencies.component.css']
})
export class PrintSaveTopFiveCompetenciesComponent implements OnInit {

  page = 1;
  pageSize = 6;
  collectionSize = 0;
  assessmentResponsedata: AssessmentResponse[];
  assessmentResponsedatalst: AssessmentResponse[];
  loggedinUser: string;
  loggedinUserID: number = 3838;
  selectedAssesmentId: number = 5667;
  @ViewChild('pdfTable', {static: false}) pdfTable: ElementRef;

  constructor(private csservice: CompetencyService,private route: ActivatedRoute) { 
  this.assessmentResponsedatalst =[];
  }
  ngOnInit(): void {
    this.assessmentResponsedatalst =[];
    var currentUserData = JSON.parse(localStorage.getItem('currentUser'));
    this.loggedinUser = currentUserData["firstName"];
    this.loggedinUserID = currentUserData["userId"];
    this.route.paramMap.subscribe(params => {
      const assesmentid = params.get('assesmentid');
      var id = parseInt(assesmentid);
      if (id != null || id != 0) {
       this.GetUserAssesmentsbyUser(assesmentid);
      }
    });
  }
GetUserAssesmentsbyUser(assesmentid) {
    if (this.loggedinUserID > 0) {
      this.csservice.GetTopFiveAssessmentResponse(this.loggedinUserID,assesmentid).subscribe(data => {
        this.assessmentResponsedata = data;
        this.assessmentResponsedatalst = this.assessmentResponsedata
      });
    }
  }

  onSort(event) {
  }
  refreshdata() {
    this.assessmentResponsedatalst = this.assessmentResponsedata
      .map((user, i) => ({ id: i + 1, ...user }))
      .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }

  onPrint(){
    
  //   const doc = new jsPDF('p', 'pt', 'letter');

    

  //  const elementToPrint = document.getElementById('pdfTable'); //The html element to become a pdf
  //  const margins = {
  //   top: 80,
  //   bottom: 60,
  //   left: 40,
  //   width: 522
  // };



  // // or
  
  // doc.fromHTML(elementToPrint.innerHTML, margins.left, margins.top, {}, function () {

  //   doc.save("Topfive.pdf");
  // }, margins);
   debugger;
  const pdfTable = this.pdfTable.nativeElement;
 
  var html = htmlToPdfmake(pdfTable.innerHTML);
   
  const documentDefinition = { content: html };
  pdfMake.createPdf(documentDefinition).download();

//   doc.addHTML(html, function() {
//     doc.save("obrz.pdf");
//  });
}

}
