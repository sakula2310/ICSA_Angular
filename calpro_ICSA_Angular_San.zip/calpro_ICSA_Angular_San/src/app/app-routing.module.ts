import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './common/login/login.component';
import { RegisterComponent } from './common/register/register.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { ReportviewerDashboardComponent } from './reportviewer-dashboard/reportviewer-dashboard.component';
import { MyprofileComponent } from './myprofile/myprofile.component';
import { AddEditUserComponent } from './add-edit-user/add-edit-user.component';
import { SampleWizardComponent } from './sample-wizard/sample-wizard.component';
import { PrioritizeComperencyComponent } from './prioritize-comperency/prioritize-comperency.component';
import { PrintSaveAllCompetenciesComponent } from './print-save-all-competencies/print-save-all-competencies.component';
import { PrintSaveTopFiveCompetenciesComponent } from './print-save-top-five-competencies/print-save-top-five-competencies.component';
import { TopFiveProfessionalDevelopmentResourcePlansComponent } from './top-five-professional-development-resource-plans/top-five-professional-development-resource-plans.component';
import { PdpPlanResourceComponent } from './pdp-plan-resource/pdp-plan-resource.component';
import { ViewAssessmentResultsComponent } from './view-assessment-results/view-assessment-results.component';

const routes: Routes = [
  { path: "", redirectTo: "login", pathMatch: "full" },
  { path: "login", component: LoginComponent },
  { path: "register", component: RegisterComponent },
  { path: "wizard/:type", component: SampleWizardComponent },
  { path: "printSaveAllCompetencies/:assesmentid", component: PrintSaveAllCompetenciesComponent },
  { path: "printSaveTopFiveCompetencies/:assesmentid", component: PrintSaveTopFiveCompetenciesComponent },
  { path: "topFiveProfessionalDevelopmentResourcePlans/:assesmentid", component: TopFiveProfessionalDevelopmentResourcePlansComponent },
  { path: "pdpPlanResource/:questionid/:rank", component: PdpPlanResourceComponent },
  { path: "viewAssessmentResults/:assesmentid", component: ViewAssessmentResultsComponent },
  { path: "admindashboard", component: AdminDashboardComponent },
  { path: "userdashboard", component: UserDashboardComponent },
  { path: "userdashboard/:result", component: UserDashboardComponent },
  { path: "reviewerdashboard", component: ReportviewerDashboardComponent },
  { path: "myprofile", component: MyprofileComponent },
  { path: "addedituser", component: AddEditUserComponent },
  { path: "addedituser/:id", component: AddEditUserComponent },
  { path:"prioritze/:id",component:PrioritizeComperencyComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  
  exports: [RouterModule]
})
export class AppRoutingModule { }
