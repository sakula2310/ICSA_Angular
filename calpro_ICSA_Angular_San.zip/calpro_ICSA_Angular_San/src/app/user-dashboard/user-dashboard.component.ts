import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StorageService } from '../services/common/stoarge.service';
import { Assesment } from '../services/ICSA/AssesmentData';
import { CompetencyService } from '../services/ICSA/competency.service';
import { LoginService } from '../services/ICSA/login.service';
import { SharedService } from '../services/ICSA/shared.service';
import { Agency } from '../shared/data/AgencyData';
import { User } from '../shared/data/UserData';
@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {
  @ViewChild('closeBtn') closeBtn: ElementRef;
  assesment: Assesment = new Assesment();
  page = 1;
  pageSize = 6;
  collectionSize = 0;
  loggedinUser: string;
  loggedinUserID: number = -1;
  assesmentdata: any[];
  assesmentdatalst: any[];
  userId: number
  isVisible: boolean = true;
  isOpenAssements: boolean = true;
  competencyType: string;
    currentAssessment: any;

  assesmentId: number;
  assesmentName: string;
  completedAssessments: string;
  startDate: string;
  resultText: string;
  resultTextColor: string;
  editagencies: Agency[];
  dropdownSettings: any = {};
  agencyList: Agency[];
  constructor(private service: LoginService, private dataServices: StorageService, private shared: SharedService, private csservice: CompetencyService, private route: Router,private activeroute:ActivatedRoute) {
    this.activeroute.paramMap.subscribe(params => {
      const id = params.get('result');
    
      if (id != null) {
      this.isVisible=false;
      
      this.getdata(JSON.parse(localStorage.getItem("assetmentdata")))
      }
    });
  }
  ngOnInit(): void {
    this.shared.enableMenuOptions(false);
    this.editagencies = [];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'codeId',
      textField: 'agencyName',
      selectAllText: 'select All',
      unSelectAllText: 'Unselect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
    this.shared.setTitle("User DashBoard");
    this.assesmentdata = [];
    this.assesmentdatalst = [];
    var currentUserData = JSON.parse(localStorage.getItem('currentUser'));
    this.loggedinUser = currentUserData["firstName"];
    this.loggedinUserID = currentUserData["userId"];
    console.log(currentUserData);
    this.GetUserAssesmentsbyUser();
    this.service.getAgenciesByUserId(this.loggedinUserID).subscribe(agencies => {
      if (agencies.result) {
        this.agencyList = agencies.result;
      }
    });

  }
  GetUserAssesmentsbyUser() {
    if (this.loggedinUserID > 0) {
      this.csservice.GetUserAssesmentsbyUser(this.loggedinUserID).subscribe(data => {
        console.log(data);
        this.assesmentdata = data;
        this.assesmentdatalst = data;
        var data = this.assesmentdata.find(x => x.assessmentStatus == 'IN PROGRESS');
		this.dataServices.setCurrentAssessment(data);
        localStorage.setItem('currentAssessment', JSON.stringify(data));
        if (data != undefined ? data.assessmentId > 0 || data : false) {
          this.isOpenAssements = false;
        }
        else {
          this.isOpenAssements = true;
        }
      });
    }
  }
  newAssesment() {
    this.resetLocalStorageData();
    this.currentAssessment = this.dataServices.getCurrentAssessment();
    debugger;
    this.shared.enableMenuOptions(true);
    if (this.currentAssessment !== undefined && this.currentAssessment !== null) {
      if (this.currentAssessment.completedCompetency === 1) {
        this.competencyType = "instruction";
      } else if (this.currentAssessment.completedCompetency === 2) {
        this.competencyType = "communicates";
      } else if (this.currentAssessment.completedCompetency === 3) {
        this.competencyType = "professionalism";
      } else if (this.currentAssessment.completedCompetency === 4) {
        this.competencyType = "professionalism";
      } else {
        this.competencyType = "data";
      }
      this.route.navigate(["/wizard", this.competencyType]);
    } else {
      this.route.navigate(["/wizard","data"]);
    }
    this.shared.enableMenuOptions(true);
  }
getdata(data){
  this.isVisible = false;
  this.assesmentId = data.assessmentId;
  this.assesmentName = data.assessmentName;
  this.completedAssessments = data.completedCompetency;
  this.startDate = data.assessmentStartDate;
  if (data.assessmentStatus != 'Completed') {
    this.resultText = 'You have completed more than ' + data.completedCompetencyinWords +
      'but fewer than four sections of this assessment, on ' + data.assessmentStartDate;
    this.resultTextColor = "Red";
  }
  else {
    if (data.completedCompetency == 4) {
      this.resultText = 'You have completed the entire assessment on ' + data.assessmentStartDate;
    }
    else {
      this.resultText = 'You have completed ' + data.completedCompetencyinWords + ' out of four areas of this assessment. (Assessment was saved and closed as of ' + data.assessmentStartDate + ')';
    }
    this.resultTextColor = "Green";
  }
  console.log(data);
}
  viewResults(data) {
    localStorage.setItem("assetmentdata",JSON.stringify(data));
    this.isVisible = false;
    this.assesmentId = data.assessmentId;
    this.assesmentName = data.assessmentName;
    this.completedAssessments = data.completedCompetency;
    this.startDate = data.assessmentStartDate;
    if (data.assessmentStatus != 'Completed') {
      this.resultText = 'You have completed more than ' + data.completedCompetencyinWords +
        'but fewer than four sections of this assessment, on ' + data.assessmentStartDate;
      this.resultTextColor = "Red";
    }
    else {
      if (data.completedCompetency == 4) {
        this.resultText = 'You have completed the entire assessment on ' + data.assessmentStartDate;
        this.shared.enableMenuOptions(true);
      }
      else {
        this.resultText = 'You have completed ' + data.completedCompetencyinWords + ' out of four areas of this assessment. (Assessment was saved and closed as of ' + data.assessmentStartDate + ')';
      }
      this.resultTextColor = "Green";
    }
    console.log(data);

  }

  viewcompleteResults() {
    this.route.navigate(["/viewAssessmentResults/" + this.assesmentId]);
  }
  viewTopFiveResults() {
    this.route.navigate(["/printSaveTopFiveCompetencies/" + this.assesmentId]);
  }
  viewAllResults() {
    this.route.navigate(["/printSaveAllCompetencies/" + this.assesmentId]);
  }
  viewTopFivePDResults() {
    this.route.navigate(["/topFiveProfessionalDevelopmentResourcePlans/" + this.assesmentId]);
  }
  SetData(data) {
    this.assesmentId = data.assessmentId;
    this.assesmentName = data.assessmentName;
    this.completedAssessments = data.completedCompetency;
    this.startDate = data.assessmentStartDate;
  }
  SaveUserAgencies() {
    if (this.editagencies.length > 0) {
      var agencyIds = this.editagencies.map(x => x.codeId).join(",");
      this.assesment.assessmentId = this.assesmentId;
      this.assesment.assessmentName = agencyIds;
      this.service.saveUserAgencies(this.assesment).subscribe(data => {
        this.closeBtn.nativeElement.click();
        if (data.includes("success")) {
          // this.showSuccess = true;
        }        
      });
    }
  }

  onSort(event) {
  }
  refreshdata() {
    this.assesmentdatalst = this.assesmentdata
      .map((user, i) => ({ id: i + 1, ...user }))
      .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }
  resetLocalStorageData(){
    localStorage.removeItem("assetmentdata");
  }
}
