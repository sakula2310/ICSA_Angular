import { Component, OnInit } from '@angular/core';
import { CompetencyService } from '../services/ICSA/competency.service';
import { MatRadioChange } from '@angular/material/radio';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TooltipComponent } from '../common/tooltip/tooltip.component';
import { QuestionResponse } from '../shared/data/QuestionResponse';
import { LEADING_TRIVIA_CHARS } from '@angular/compiler/src/render3/view/template';
import { UpperCasePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedService } from '../services/ICSA/shared.service';
import { StorageService } from '../services/common/stoarge.service';
import { stringify } from '@angular/compiler/src/util';
import { OptionsList, Questions } from '../shared/data/Questions';

@Component({
  selector: 'app-sample-wizard',
  templateUrl: './sample-wizard.component.html',
  styleUrls: ['./sample-wizard.component.css'],
})
export class SampleWizardComponent implements OnInit {
  questions: Questions[] = [];
  competencyType: string;
  finalArray: any;
  someName: any;
  selquestion: any;
  updateResponse: QuestionResponse[] = [];
  userId: number;
  assessmentId: number;
  AssessmentCompleted: boolean;
  competencyId: number = 1;
  currentAssessment: any;
  isEnableMenu: boolean = false;
  agencyId: any;
  saveAndCompBtnVisible = true;
  missingAns = false;
  defaultLoadded = true;

  constructor(private service: CompetencyService, private activatedRoute: ActivatedRoute, private route: Router, public dialog: MatDialog
    , private shared: SharedService, private dataServices: StorageService) {

    this.assessmentId = 0;
    this.competencyType = 'Monitors and manages student learning and performance through data';
    var currentUserData = JSON.parse(localStorage.getItem('currentUser'));
    this.userId = currentUserData["userId"];

  }

  openIndicaters(question: any) {

    const dialogRef = this.dialog.open(TooltipComponent, {
      maxHeight: '500px',
      data: question
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      // this.animal = result;
    });

  }
  headertext: any;
  rownum: any;
  ngOnInit() {
    debugger;
    if (localStorage.getItem('currentAssessment') !== "undefined") {
      this.currentAssessment = JSON.parse(localStorage.getItem('currentAssessment'));
      if (this.currentAssessment != undefined && this.currentAssessment.assessmentId > 0) {
        this.assessmentId = this.currentAssessment.assessmentId;
        this.shared.enableMenuOptions(true);
      }
      console.log('current', this.currentAssessment)
    }
    if (localStorage.getItem('assetmentdata') !== "undefined") {
      this.currentAssessment = JSON.parse(localStorage.getItem('assetmentdata'));
      if (this.currentAssessment != undefined && this.currentAssessment.assessmentId > 0) {
        this.assessmentId = this.currentAssessment.assessmentId;
        this.saveAndCompBtnVisible = false;
      }
      console.log('viewAssement', this.currentAssessment)
    }

    this.activatedRoute.paramMap.subscribe(params => {
      if (params.get("type") != null) {
        this.shared.enableMenuOptions(true);

        if (params.get("type") == "data") {
          this.rownum = "I"
          this.competencyId = 1;
          this.competencyType = "Monitors and manages student learning and performance through data";
        }
        if (params.get("type") == "instruction") {
          this.rownum = "II";
          this.competencyId = 2;
          this.competencyType = "Plans and delivers high-quality, evidence-based instruction";
        }
        if (params.get("type") == "communicates") {
          this.rownum = "III";
          this.competencyId = 3;
          this.competencyType = "Effectively communicates to motivate and engage learners";
        }
        if (params.get("type") == "professionalism") {
          this.rownum = "IV";
          this.competencyId = 4;
          this.competencyType = "Pursues professionalism and continually builds knowledge and skills";
        }
        if (params.get("type") == "totaAssessment") {
          this.rownum = "V";
          this.competencyId = 5;
          this.competencyType = "CompletAssessment";
        }

        if (this.assessmentId == 0) {
          if (this.competencyType == "CompletAssessment") {
            this.getAllQuestions();
          }
          else {
            this.getQuestionsByType();
          }
        }
        else {
          this.getQuestionResponse();
        }
      }
    });
  }
  getClasstext(i) {
    var y = "que-" + i;
    var classdata = this.errorlist.filter(x => x == y);
    if (classdata.length > 0)
      return true;
    else return false;
  }
  errorlist = [];
  getQuestionsByType() {
    if (this.competencyType != "") {
      this.service.getQuestionsByCompetencyType(this.competencyType).subscribe(data => {
        console.log(data);
        this.questions = data;
      });
    }
    else {

    }
  }
  getAllQuestions() {
    if (this.competencyType != "") {
      this.service.getAllCompetencyQuestions().subscribe(data => {
        console.log(data);
        this.questions = data;
      });
    }
    else {

    }
  }


  radioChange(event: MatRadioChange, data, section) {
    debugger;
    
     var qusIndex = this.questions.findIndex(x=>x.questionId== data.questionId);
     if(section=="1")
     this.questions[qusIndex].optionsList1.map((x: any)=>{
       x.isAns=true;
     });
     else if(section =="2"){
      this.questions[qusIndex].optionsList2.map((x: any)=>{
        x.isAns=true;
      });
     } else if(section =="3"){
      this.questions[qusIndex].optionsList3.map((x: any)=>{
        x.isAns=true;
      });
     }
   
    console.log(data, event, section);
    var res = this.updateResponse.findIndex(x => x.questionId == data.questionId);
    console.log('check', res);
    var obj = {
      questionId: data.questionId,
      optionOneText: (section == 1) ? event.value : null,
      optionTwoText: (section == 2) ? event.value : null,
      optionThreeText: (section == 3) ? event.value : null
    }
    if (res >= 0) {
      if (section == 1)
        this.updateResponse[res].optionOneText = event.value;
      else if (section == 2)
        this.updateResponse[res].optionTwoText = event.value;
      else if (section == 3)
        this.updateResponse[res].optionThreeText = event.value;
    } else {
      this.updateResponse.push(obj);
    }
    console.log('response', this.updateResponse);
  }
  Cancel_Click() {
    this.shared.enableMenuOptions(false);
    this.route.navigate(["/userdashboard"]);
  }
  SaveandClose_Click() {
   // this.defaultLoadded = false
    if (this.questions.length == this.updateResponse.length) {
      var anslist = this.updateResponse.filter(x => x.optionOneText == null || x.optionTwoText == null || x.optionThreeText == null);
      if (anslist.length == 0) {
        var requestObj = {
          questionResponse: this.updateResponse,
          competencyId: this.competencyId,
          assessmentId: this.assessmentId,
          userId: this.userId,
          assessmentClose: true,
          agencyId: this.agencyId
        }
        this.saveAssessment(requestObj, 'close');
      }
      else {

      }
    }
    else {
      for (let i = 0; i < this.questions.length; i++) {
        var filterdata = this.updateResponse.filter(x => x.questionId == this.questions[i].questionId && x.optionOneText == null || x.optionTwoText == null || x.optionThreeText == null);
        if (filterdata.length > 0 || this.updateResponse.length == 0) {
          this.errorlist.push("que-" + i);
        }
      }
    }
  }

  Submit_Click() {
    debugger;
    this.errorlist = [];
    this.defaultLoadded = false
    if (this.questions.length == this.updateResponse.length) {
      var anslist = this.updateResponse.filter(x => x.optionOneText == null || x.optionTwoText == null || x.optionThreeText == null);
      if (anslist.length == 0) {
        let assessmentStatus = false;
        this.service.getAssessmentStatusbyAssessmentId(this.assessmentId, this.userId).subscribe(data => {
          console.log(data);
          if (data != null) {
            if (data.competencyStatus1 && data.competencyStatus2 &&
              data.competencyStatus3 && data.competencyStatus4) {
              assessmentStatus = true;
            } else {
              assessmentStatus = false;
            }
          }
          console.log('updateResponse', this.updateResponse);
          console.log('Question', this.questions);
          var requestObj = {
            questionResponse: this.updateResponse,
            competencyId: this.competencyId,
            assessmentId: this.assessmentId,
            userId: this.userId,
            assessmentClose: assessmentStatus,
            agencyId: this.agencyId
          }

          this.saveAssessment(requestObj);


        });
      }
      else {
        for (let i = 0; i < this.questions.length; i++) {
          var filterdata = this.updateResponse.filter(x => x.questionId == this.questions[i].questionId && x.optionOneText == null || x.optionTwoText == null || x.optionThreeText == null);
          if (filterdata.length > 0) {
            this.errorlist.push("que-" + i);
          }
        }
      }
    }
    else {
      for (let i = 0; i < this.questions.length; i++) {
        var filterdata = this.updateResponse.filter(x => x.questionId == this.questions[i].questionId && x.optionOneText == null || x.optionTwoText == null || x.optionThreeText == null);
        if (filterdata.length > 0 || this.updateResponse.length == 0) {
          this.errorlist.push("que-" + i);
        }
      }
    }
  }
  getAssessmentStatus(assessmentId: number, userId: number) {
    this.service.getAssessmentStatusbyAssessmentId(assessmentId, userId).subscribe(data => {
      console.log(data);
      if (!data.competencyStatus1 && !data.competencyStatus2 &&
        !data.competencyStatus3 && !data.competencyStatus4) {
        return true;
      } else {
        return false;
      }
    });
  }

  saveAssessment(requestObj: any, type: any = '') {
    debugger;
    if (type == '') {
      this.service.saveAssessmentByCompetencyId(requestObj).subscribe(data => {
        console.log(data);
        localStorage.setItem("currentComptencyName", JSON.stringify(this.competencyType));
        localStorage.setItem("nextComptencyId", JSON.stringify(this.competencyId + 1))

        debugger;
        this.route.navigate(["/prioritze", data.assessmentId]);
      });
    }
    else {
      this.service.saveAssessment(requestObj).subscribe(data => {
        console.log(data);
        localStorage.setItem("currentComptencyName", JSON.stringify(this.competencyType));
        localStorage.setItem("nextComptencyId", JSON.stringify(5))
        this.route.navigate(["/prioritze", data.assessmentId]);

      });
    }
  }

  getQuestionResponse() {
    debugger;
    if (this.competencyType != "" && this.assessmentId > 0 && this.userId > 0) {
      this.service.getQuestionResponseById(this.competencyType, this.assessmentId, this.userId).subscribe(data => {
        console.log(data);
        this.questions = data;
        // this.updateResponse = data;

        if (this.questions == null || this.questions.length == 0) {
          this.getQuestionsByType();
        } else {
          data.forEach(x => {
            var obj = {
              questionId: x.questionId,
              optionOneText: x.optionsList1.filter(one => one.isChecked)[0].optionId,
              optionTwoText: x.optionsList2.filter(one => one.isChecked)[0].optionId,
              optionThreeText: x.optionsList3.filter(one => one.isChecked)[0].optionId
            };
            this.updateResponse.push(obj);
          });
        }
      });
    }
    else {

    }
  }
}
