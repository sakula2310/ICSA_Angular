import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SampleWizardComponent } from './sample-wizard.component';

describe('SampleWizardComponent', () => {
  let component: SampleWizardComponent;
  let fixture: ComponentFixture<SampleWizardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SampleWizardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SampleWizardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
