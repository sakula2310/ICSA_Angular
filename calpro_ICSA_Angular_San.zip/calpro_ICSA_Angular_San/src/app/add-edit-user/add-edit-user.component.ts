import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from 'src/app/services/ICSA/login.service';
import { MasterService } from 'src/app/services/ICSA/master.service';
import { SharedService } from 'src/app/services/ICSA/shared.service';
import { Agency } from 'src/app/shared/data/AgencyData';
import { User } from 'src/app/shared/data/UserData';

@Component({
  selector: 'app-add-edit-user',
  templateUrl: './add-edit-user.component.html',
  styleUrls: ['./add-edit-user.component.css']
})
export class AddEditUserComponent implements OnInit {

  errorMessage: string;
  user: User = new User();
  agencyList: Agency[];
  roleList: any;
  myform: FormGroup;
  submitted = false;
  validateAgency: boolean;
  selectedAgencies: any;
  dropdownSettings: any = {};
  isEdit: boolean;
  showSuccess: boolean;

  constructor(private service: LoginService,
    private master: MasterService, private route: Router,
    private formBuilder: FormBuilder, private shared: SharedService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'codeId',
      textField: 'agencyName',
      selectAllText: 'select All',
      unSelectAllText: 'Unselect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
    this.loadAgencyList();
    this.loadRoles();
    this.shared.setTitle("")

    this.activatedRoute.paramMap.subscribe(params => {
      if (params.get("id") != null) {
        this.isEdit = true;
        this.loadUserDetails(params.get("id"));
      }
      else {
        this.isEdit = false;
      }
    });
  }

  loadUserDetails(userId) {
    if (userId != "") {
      this.service.getUserInfoByUserId(userId).subscribe(data => {
        var userDetails = data.result;
        if (userDetails) {
          this.user.userId = userDetails.userId;
          this.user.email = userDetails.userEmailId;
          this.user.firstName = userDetails.firstName;
          this.user.lastName = userDetails.lastName;
          // this.user.password = userDetails.password;
          // this.user.confirmPassword = userDetails.password;
          this.user.role = userDetails.roleId;
          this.service.getAgenciesByUserId(userId).subscribe(agencies => {
            if (agencies.result) {
              this.user.agencies = agencies.result;
            }
          });
        }
      });
    }
    else {
      this.isEdit = false;
    }
  }
  loadAgencyList() {
    this.master.getAgencies().subscribe(data => {
      this.agencyList = data;
    });
  }
  loadRoles() {
    this.service.getRoles().subscribe(data => {
      this.roleList = data;
      // this.roleList = [{ roleName: "Instructor", roleId: 1 }, { roleName: "Admin", roleId: 2 }, { roleName: "Report Viewer", roleId: 3 }];
    });
  }

  userAvailability() {
    this.errorMessage = '';
    if (this.user.email != "") {
      this.service.userAvailability(this.user.email).subscribe(data => {
        console.log(data);
        if (data.result === true) {
          this.errorMessage = 'User already exists – Please select another username';
        }
        else {
          this.errorMessage = 'User available';
        }
      });
    }
    else {
      this.errorMessage = 'E-mail address should not be empty';
    }
  }
  saveUser() {
    if (!this.isEdit) {
      this.addUser()
    }
    else {
      this.updateUser()
    }
  }
  addUser() {
    this.submitted = true;
    this.validateAgency = false;
    if (this.user.agencies.length > 0) {
      this.user.agencyIds = this.user.agencies.map(x => x.codeId).join(",");
      this.service.register(this.user).subscribe(data => {
        console.log(data);
        if (data.result.includes("Successfully")) {
          this.route.navigate(["/admindashboard"]);
        }
        else {
          this.errorMessage = data.result;
        }
      });
    }
    else {
      this.validateAgency = true;
    }
  }

  updateUser() {
    this.submitted = true;
    this.validateAgency = false;
    if (this.user.agencies.length > 0) {
      this.user.agencyIds = this.user.agencies.map(x => x.codeId).join(",");
      this.service.updateUserDetails(this.user).subscribe(data => {
        if (data.includes("success")) {
          this.showSuccess = true;
        }
        else {
          this.errorMessage = data.result;
        }
      });
    }
    else {
      this.validateAgency = true;
    }
  }
  reset(f: any) {
    f.submitted = false;
    f.agencies = [];
    f.reset();
  }
  navigateToDashboard() {
    this.isEdit = false;
    this.route.navigate(["/admindashboard"]);
  }
}
