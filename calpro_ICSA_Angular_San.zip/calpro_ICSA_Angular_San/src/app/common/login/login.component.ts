import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/ICSA/login.service';
import { SharedService } from 'src/app/services/ICSA/shared.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username: string;
  pwd: string;
  constructor(private service: LoginService, private route: Router, private shared: SharedService) {
    this.username = "";
    this.pwd = "";
  }

  ngOnInit(): void {
    localStorage.removeItem('currentUser');
    localStorage.clear();
    this.service.currentUserSubject.next(null);
    this.shared.setMenuVisibility(false);
    this.shared.setTitle("CALPRO Login");
  }
  login() {
    var req = {
      "emailId": this.username,
      "password": this.pwd
    };
    this.service.login(req).subscribe(data => {
      console.log(data);
      if (data.result.userId > 0) {

        if (data.result.roleId == 2) {
          this.route.navigate(["/admindashboard"]);
        }
        else if (data.result.roleId == 3) {
          this.route.navigate(["/reviewerdashboard"]);
        }
        else {
          this.route.navigate(["/userdashboard"]);
        }

      }
      else {
        alert("invalid usernmae and password");
      }
    });

  }

  forgetPassword() {
    if (this.username !== null && this.username !== undefined && this.username !== '') {

    }
  }
}
