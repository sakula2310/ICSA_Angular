import { Component, OnInit, OnChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { LoginService } from 'src/app/services/ICSA/login.service';
import { SharedService } from 'src/app/services/ICSA/shared.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnChanges {
  isShow: boolean = false;
  currentUser: any;
  headername: any;
  currentUserSubscription: Subscription;
  users: any[] = [];
  constructor(private service: LoginService, private route: Router, private aRouter: ActivatedRoute, private shared: SharedService) {
  }

  ngOnInit(): void {
    this.shared.title.subscribe(value => this.headername = value);
    this.currentUserSubscription = this.service.currentUser.subscribe(user => {
      this.currentUser = user;
      if (this.currentUser != null) {
        if (this.currentUser.userId > 0) {
          this.isShow = true;
        }
      }
      else {
        this.isShow = false;
      }
    });
  }
  ngOnChanges() {
    this.shared.title.subscribe(value => this.headername = value);
  }
  myProfile() {
    this.route.navigate(['/myprofile']);
  }
  logout() {
    localStorage.removeItem('currentUser');
    localStorage.clear();
    this.isShow = false;
    this.service.change(null);
    this.service.currentUserSubject.next(null);
    this.shared.setMenuVisibility(false);
    this.shared.enableMenuOptions(false);
    this.route.navigate(['/login']);
  }
}
