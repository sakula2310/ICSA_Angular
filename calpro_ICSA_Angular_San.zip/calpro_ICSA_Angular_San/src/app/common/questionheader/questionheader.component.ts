import { Component, OnInit } from '@angular/core';
import { MatRadioChange } from '@angular/material/radio';
import { CompetencyService } from 'src/app/services/ICSA/competency.service';

@Component({
  selector: 'app-questionheader',
  templateUrl: './questionheader.component.html',
  styleUrls: ['./questionheader.component.css']
})
export class QuestionheaderComponent implements OnInit {

  questions: any[] = [];
  competencyType: string;
  finalArray: any;
  someName: any;
  
  constructor(private service: CompetencyService) {
    this.questions =
    
      [
        {
          "optionsList1": [
            {
              "optionId": 1,
              "isChecked": false
            },
            {
              "optionId": 2,
              "isChecked": false
            },
            {
              "optionId": 3,
              "isChecked": true
            },
            {
              "optionId": 4,
              "isChecked": false
            }
          ],
          "optionsList2": [
            {
              "optionId": 1,
              "isChecked": false
            },
            {
              "optionId": 2,
              "isChecked": false
            },
            {
              "optionId": 3,
              "isChecked": true
            },
            {
              "optionId": 4,
              "isChecked": false
            }
          ],
          "optionsList3": [
            {
              "optionId": 1,
              "isChecked": false
            },
            {
              "optionId": 2,
              "isChecked": false
            },
            {
              "optionId": 3,
              "isChecked": true
            },
            {
              "optionId": 4,
              "isChecked": false
            }
          ],
          "quesIndicaters": [
            {
              "questionId": 1,
              "subQuestionTypeId": null,
              "indicatorId": 3,
              "indicatorIndex": 1.1,
              "indicatorText": "Collects and reviews information on learners’ content knowledge; prior learning experiences; and learning needs from school transcripts, questionnaires, and learner interviews",
              "indicatorTypeId": 1,
              "indicatorTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 1,
              "subQuestionTypeId": null,
              "indicatorId": 4,
              "indicatorIndex": 1.2,
              "indicatorText": "Collects and updates information on learners’ goals through interviews and/or questionnaires",
              "indicatorTypeId": 1,
              "indicatorTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 1,
              "subQuestionTypeId": null,
              "indicatorId": 5,
              "indicatorIndex": 1.3,
              "indicatorText": "Reviews the results of program-created and required standardized assessments such as the Tests of Adult Basic Education (TABE), Comprehensive Adult Student Assessment Systems (CASAS), and other assessments",
              "indicatorTypeId": 1,
              "indicatorTypeText": "Monitors and manages student learning and performance through data"
            }
          ],
          "illustrations": [
            {
              "questionId": 1,
              "subQuestionTypeId": null,
              "illustrationId": 1,
              "illustrationIndex": 1.1,
              "illustrationText": "On the first day of class, the teacher of a multilevel English as a\r\nsecond language (ESL) class identifies learners’ needs and proficiency\r\nlevels by asking learners to do quickwrites to describe themselves. The\r\nstudents can use pictures, words, sentences, and/or paragraphs. These\r\nquickwrites, coupled with short student surveys about their learning\r\nbackgrounds, are placed in student portfolios and will be used in future\r\nstudent-teacher interviews",
              "illustrationTypeId": 1,
              "illustrationTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 1,
              "subQuestionTypeId": null,
              "illustrationId": 2,
              "illustrationIndex": 1.2,
              "illustrationText": "An Adult Basic Education (ABE) literacy teacher administers\r\nlearner self-assessments at the beginning, middle, and end of the\r\nsemester. The literacy teacher also collects work samples (e.g., student\r\nwritings, student-made dictionaries, and quizzes) and helps the learners\r\norganize the information into portfolios. The ABE literacy teacher uses\r\nthese portfolios during progress conferences and with learners who are\r\nfeeling frustrated with their progress",
              "illustrationTypeId": 1,
              "illustrationTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 1,
              "subQuestionTypeId": null,
              "illustrationId": 3,
              "illustrationIndex": 1.3,
              "illustrationText": "An Adult Secondary Education (ASE) bridge to college\r\nmathematics instructor supplements the results of the program’s\r\nstandardized mathematics assessment by developing an assessment that\r\nincorporates mathematics content from a high school equivalency (HSE)\r\nexam and also from a local college placement exam. By reviewing\r\nresults from both exams, the instructor is able to identify learners who\r\nwould benefit from a bridge to college mathematics course, show\r\nlearners why they would benefit from the course, and guide decisions\r\nabout content for the course.",
              "illustrationTypeId": 1,
              "illustrationTypeText": "Monitors and manages student learning and performance through data"
            }
          ],
          "questionId": 1,
          "questionText": "Assesses learners’ prior knowledge, learning needs, and college and career readiness goals",
          "option1": null,
          "option2": null,
          "option3": null
        },
        {
          "optionsList1": [
            {
              "optionId": 1,
              "isChecked": false
            },
            {
              "optionId": 2,
              "isChecked": false
            },
            {
              "optionId": 3,
              "isChecked": true
            },
            {
              "optionId": 4,
              "isChecked": false
            }
          ],
          "optionsList2": [
            {
              "optionId": 1,
              "isChecked": false
            },
            {
              "optionId": 2,
              "isChecked": false
            },
            {
              "optionId": 3,
              "isChecked": true
            },
            {
              "optionId": 4,
              "isChecked": false
            }
          ],
          "optionsList3": [
            {
              "optionId": 1,
              "isChecked": false
            },
            {
              "optionId": 2,
              "isChecked": false
            },
            {
              "optionId": 3,
              "isChecked": true
            },
            {
              "optionId": 4,
              "isChecked": false
            }
          ],
          "quesIndicaters": [
            {
              "questionId": 2,
              "subQuestionTypeId": null,
              "indicatorId": 6,
              "indicatorIndex": 2.1,
              "indicatorText": "Refers to assessments of students’ learning needs and strengths, incoming content knowledge, and prior learning experiences to design courses of study and align learning goals",
              "indicatorTypeId": 1,
              "indicatorTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 2,
              "subQuestionTypeId": null,
              "indicatorId": 7,
              "indicatorIndex": 2.2,
              "indicatorText": "Designs courses of study that link course content to learners’ interests and goals and expose learners to new ideas and experiences that may help them to refine or change their goals over time",
              "indicatorTypeId": 1,
              "indicatorTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 2,
              "subQuestionTypeId": null,
              "indicatorId": 8,
              "indicatorIndex": 2.3,
              "indicatorText": "Supports students’ continued learning and college and career goals by providing access to advisors and counselors or planning tools",
              "indicatorTypeId": 1,
              "indicatorTypeText": "Monitors and manages student learning and performance through data"
            }
          ],
          "illustrations": [
            {
              "questionId": 2,
              "subQuestionTypeId": null,
              "illustrationId": 4,
              "illustrationIndex": 2.1,
              "illustrationText": "An ABE reading teacher finds that current learners, in their\r\nprevious reading classes, answered basic comprehension questions from\r\nbooks written for adult emerging readers. With this information, the\r\nABE reading teacher designs a series of activities that deepen learners’\r\nreading comprehension of slightly more challenging texts. The first\r\nactivity asks learners to write letters to a character in the book, advising\r\nthat character about how to solve a problem he or she is facing",
              "illustrationTypeId": 1,
              "illustrationTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 2,
              "subQuestionTypeId": null,
              "illustrationId": 5,
              "illustrationIndex": 2.2,
              "illustrationText": "The teacher of a low-level ESL class supplies a diagram of\r\npossible student pathways upon completion of this class. Learners are\r\nasked to identify where they are in the diagram and where they would\r\nlike to go. They then make similar diagrams of the school systems in\r\ntheir native countries and share the diagrams with the class.",
              "illustrationTypeId": 1,
              "illustrationTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 2,
              "subQuestionTypeId": null,
              "illustrationId": 6,
              "illustrationIndex": 2.3,
              "illustrationText": "The teacher of an intermediate ESL class invites a college and\r\ncareer counselor to visit the class. Before the visit, the teacher presents a\r\nlesson on types of questions that a college and career counselor might be\r\nable to answer. Each learner identifies three questions to ask. The\r\nteacher collects the questions, identifies the 10 most common questions,\r\nand supplies them ahead of time to the counselor so that the counselor\r\ncan tailor her presentation. At the end of the presentation, the counselor\r\nsets up one-on-one appointments so learners can ask personal questions.",
              "illustrationTypeId": 1,
              "illustrationTypeText": "Monitors and manages student learning and performance through data"
            }
          ],
          "questionId": 2,
          "questionText": "Sets learning goals and a course of study",
          "option1": null,
          "option2": null,
          "option3": null
        },
        {
          "optionsList1": [
            {
              "optionId": 1,
              "isChecked": false
            },
            {
              "optionId": 2,
              "isChecked": false
            },
            {
              "optionId": 3,
              "isChecked": true
            },
            {
              "optionId": 4,
              "isChecked": false
            }
          ],
          "optionsList2": [
            {
              "optionId": 1,
              "isChecked": false
            },
            {
              "optionId": 2,
              "isChecked": false
            },
            {
              "optionId": 3,
              "isChecked": true
            },
            {
              "optionId": 4,
              "isChecked": false
            }
          ],
          "optionsList3": [
            {
              "optionId": 1,
              "isChecked": false
            },
            {
              "optionId": 2,
              "isChecked": false
            },
            {
              "optionId": 3,
              "isChecked": true
            },
            {
              "optionId": 4,
              "isChecked": false
            }
          ],
          "quesIndicaters": [
            {
              "questionId": 3,
              "subQuestionTypeId": null,
              "indicatorId": 9,
              "indicatorIndex": 3.1,
              "indicatorText": "Uses a variety of formative assessment tools (such as classroom observations, lesson closure discussions, portfolios, quizzes, and student error logs) to monitor learning and adjust instruction",
              "indicatorTypeId": 1,
              "indicatorTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 3,
              "subQuestionTypeId": null,
              "indicatorId": 11,
              "indicatorIndex": 3.2,
              "indicatorText": "Provides regular, detailed feedback to learners on the progress of their learning",
              "indicatorTypeId": 1,
              "indicatorTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 3,
              "subQuestionTypeId": null,
              "indicatorId": 12,
              "indicatorIndex": 3.3,
              "indicatorText": "Uses required summative assessments to measure student progress toward learning goals over a specific instructional period and to make decisions about placement and goal-setting in a subsequent instructional period",
              "indicatorTypeId": 1,
              "indicatorTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 3,
              "subQuestionTypeId": null,
              "indicatorId": 10,
              "indicatorIndex": 3.4,
              "indicatorText": "Assists learners in reflecting on their own performance",
              "indicatorTypeId": 1,
              "indicatorTypeText": "Monitors and manages student learning and performance through data"
            }
          ],
          "illustrations": [
            {
              "questionId": 3,
              "subQuestionTypeId": null,
              "illustrationId": 7,
              "illustrationIndex": 3.1,
              "illustrationText": "At the end of each day’s lesson, an ABE instructor asks learners\r\nto write individual responses to one or two brief prompts relating to that\r\nday’s key lesson objectives. These answers provide the instructor with a\r\nsnapshot of student understanding that the instructor combines with\r\nother formative assessments in planning for the next lesson",
              "illustrationTypeId": 1,
              "illustrationTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 3,
              "subQuestionTypeId": null,
              "illustrationId": 8,
              "illustrationIndex": 3.2,
              "illustrationText": "After 3 weeks of instruction, a bridge to college instructor holds a\r\nconference with each learner to review his or her attendance, class\r\nparticipation, organizational habits, and academic progress. The\r\nconferences provide each learner with an early opportunity to discuss\r\nareas of strength and concern",
              "illustrationTypeId": 1,
              "illustrationTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 3,
              "subQuestionTypeId": null,
              "illustrationId": 9,
              "illustrationIndex": 3.3,
              "illustrationText": "A team of ESL instructors reviews the results and diagnostic\r\ninformation from the program’s standardized language skills assessment\r\nat the end of a cycle and uses a shared rubric to decide which students\r\nwill advance to the next level. In addition to appropriately placing\r\nlearners, the collaboration strengthens teachers’ abilities to evaluate\r\nstudent writing.",
              "illustrationTypeId": 1,
              "illustrationTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 3,
              "subQuestionTypeId": null,
              "illustrationId": 10,
              "illustrationIndex": 3.4,
              "illustrationText": "At the beginning of a semester, an HSE teacher administers a\r\nlearning goal assessment. At the end of an instructional unit, the HSE\r\nteacher administers a teacher-developed formative assessment. The HSE\r\nteacher shares the results with learners and works with them to tie the\r\nresults to their learning goals (e.g., “I’ll be able to identify main ideas\r\nmore easily by the end of the semester”), not just global skill\r\nimprovements (e.g., “I’ll be a better reader”).",
              "illustrationTypeId": 1,
              "illustrationTypeText": "Monitors and manages student learning and performance through data"
            }
          ],
          "questionId": 3,
          "questionText": "Monitors learning through summative and formative assessment data",
          "option1": null,
          "option2": null,
          "option3": null
        },
        {
          "optionsList1": [
            {
              "optionId": 1,
              "isChecked": false
            },
            {
              "optionId": 2,
              "isChecked": false
            },
            {
              "optionId": 3,
              "isChecked": true
            },
            {
              "optionId": 4,
              "isChecked": false
            }
          ],
          "optionsList2": [
            {
              "optionId": 1,
              "isChecked": false
            },
            {
              "optionId": 2,
              "isChecked": false
            },
            {
              "optionId": 3,
              "isChecked": true
            },
            {
              "optionId": 4,
              "isChecked": false
            }
          ],
          "optionsList3": [
            {
              "optionId": 1,
              "isChecked": false
            },
            {
              "optionId": 2,
              "isChecked": false
            },
            {
              "optionId": 3,
              "isChecked": true
            },
            {
              "optionId": 4,
              "isChecked": false
            }
          ],
          "quesIndicaters": [
            {
              "questionId": 4,
              "subQuestionTypeId": null,
              "indicatorId": 13,
              "indicatorIndex": 4.1,
              "indicatorText": "Uses formative assessment data to plan a range of supplemental activities for use with learners who struggle to achieve the lesson objectives or who would benefit from an extra challenge",
              "indicatorTypeId": 1,
              "indicatorTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 4,
              "subQuestionTypeId": null,
              "indicatorId": 14,
              "indicatorIndex": 4.2,
              "indicatorText": "Uses diagnostic information from required summative assessments to adapt instruction to reach learners who have difficulty with a particular approach and to deepen learner understanding more generally",
              "indicatorTypeId": 1,
              "indicatorTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 4,
              "subQuestionTypeId": null,
              "indicatorId": 15,
              "indicatorIndex": 4.3,
              "indicatorText": "Uses student performance data to make judgments about when and how to diverge from a lesson plan in response to learning needs as they emerge",
              "indicatorTypeId": 1,
              "indicatorTypeText": "Monitors and manages student learning and performance through data"
            }
          ],
          "illustrations": [
            {
              "questionId": 4,
              "subQuestionTypeId": null,
              "illustrationId": 11,
              "illustrationIndex": 4.1,
              "illustrationText": "An intermediate-level ESL teacher collects two writing samples—\r\na personal story and a summary of a short newspaper article—from\r\nstudents in the first 3 weeks of class. The teacher analyzes the samples\r\nfor learner strengths and weaknesses in idea development, grammar and\r\nusage, and vocabulary use. The teacher then plans a series of learning\r\nstations so that students can work independently, in small groups, or\r\nwith the teacher to practice specific language skills.",
              "illustrationTypeId": 1,
              "illustrationTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 4,
              "subQuestionTypeId": null,
              "illustrationId": 12,
              "illustrationIndex": 4.2,
              "illustrationText": "In an intermediate ABE classroom, the teacher, after reviewing a\r\nmidterm standardized assessment, notes that two students are having\r\nsimilar difficulties in independently evaluating information about\r\nreading passages. The teacher finds a reading passage or text of interest\r\nto both of them and asks them to work together to analyze the reading\r\npassage and put it into a classification chart",
              "illustrationTypeId": 1,
              "illustrationTypeText": "Monitors and manages student learning and performance through data"
            },
            {
              "questionId": 4,
              "subQuestionTypeId": null,
              "illustrationId": 13,
              "illustrationIndex": 4.3,
              "illustrationText": "A bridge to college instructor is conducting a lesson on persuasive\r\nwriting. Students are reading a text that includes data, presented in a\r\ngraph, which appear to support the writer’s point of view. The instructor\r\nobserves that the students are unable to discern how the scale of the\r\ngraph affects the appearance of the data. The instructor decides to\r\ninterrupt the lesson and asks students to use different scales to graph the\r\nsame data. Through this impromptu work, students gain the ability to\r\nmanipulate the appearance of a graph and to identify this manipulation\r\nin graphs created by others.",
              "illustrationTypeId": 1,
              "illustrationTypeText": "Monitors and manages student learning and performance through data"
            }
          ],
          "questionId": 4,
          "questionText": "Adapts instruction based on formative and summative student assessment data",
          "option1": null,
          "option2": null,
          "option3": null
        }
      ];
    
  }

  ngOnInit(): void {
    this.getQuestionsByType();
  }

   getQuestionsByType() {
    
    if (this.competencyType != "") {
      this.service.getQuestionsByCompetencyType(this.competencyType).subscribe(data => {
        console.log(data);
        // this.questions = data;
      });
    }
    else {
      
    }
   }
  
  radioChange(event: MatRadioChange, data) {
    console.log(data,event);
    //var obj = this.questions.filter(x => x.id == data.id)[0];
    // console.log(obj);
    // obj.selected = event.value;
    // console.log(this.finalArray.some(x => x.id == data.id))
    // if (!this.finalArray.some(x => x.id == data.id)) {
    //   this.finalArray.push(obj);
    // }
  }
}
