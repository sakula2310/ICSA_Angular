import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { ReportService } from '../services/ICSA/report.service';
import { SharedService } from '../services/ICSA/shared.service';

@Component({
  selector: 'app-reportviewer-dashboard',
  templateUrl: './reportviewer-dashboard.component.html',
  styleUrls: ['./reportviewer-dashboard.component.css']
})
export class ReportviewerDashboardComponent implements OnInit {

   public barChartOptions: ChartOptions = {
    responsive: true,
  };
  public barChartLabels: Label[] = [];
  public barChartType: ChartType = 'horizontalBar';
  public barChartLegend = false;
  public barChartPlugins = [];
selectedQuantity:any;
  public barChartData: ChartDataSets[] = [  ];
startDate:any;
endDate:any;
isShowchart:boolean=false;
isShowGrid:boolean=false;
datalist=[];
actualRes=[];
labelList=[];
totalLabelList=[];
mixiedDataele=[];
totaldatalist=[];
  constructor(private shared: SharedService, private service: ReportService, private route: Router) {
  }
  ngOnInit() {
        this.shared.setTitle("ReportViewer DashBoard");

  }
   getRandomColor() {
    var color = Math.floor(0x1000000 * Math.random()).toString(16);
    return '#' + ('000000' + color).slice(-6);
  }
  changevalue(eve){
    debugger;
    var topValues = this.totaldatalist.sort((a,b) => b-a).slice(0,Number(eve.target.value));
   var data=this.mixiedDataele.sort((a, b) => (a.value > b.value ? -1 : 1));
  var  res = data.filter((person) => topValues.includes(person.value) ).map(x=>x.label);
  this.barChartData=[];
   // this.barChartLabels=res.slice(0,Number(eve.target.value));
    for (let k = 0; k < this.barChartLabels.length; k++) {
            for (let i = 0; i < res.length; i++) {
              var dd=data.filter(x=>x.label==res[i])[0];
              if(dd.groupName==this.barChartLabels[k] && k==0){
                var y:any={};
                y.data=[dd.value,"","",""];
                y.label="Question"+" "+ res[i];
                                y.backgroundColor=this.getRandomColor();

                 this.barChartData.push(y);
                

              }
               if(dd.groupName==this.barChartLabels[k] && k==1){
                var y:any={};
                y.data=["",dd.value,"",""];
                y.label="Question"+" "+ res[i];
                                y.backgroundColor=this.getRandomColor();

                 this.barChartData.push(y);
                
              }
               if(dd.groupName==this.barChartLabels[k] && k==2){
                var y:any={};
                y.data=["","",dd.value,""];
                y.label="Question"+" "+ res[i];
                                y.backgroundColor=this.getRandomColor();

                 this.barChartData.push(y);
                 

              }
               if(dd.groupName==this.barChartLabels[k] && k==3){
                var y:any={};
                y.data=["","","",dd.value];
                y.label="Question"+" "+ res[i];
                                y.backgroundColor=this.getRandomColor();

                 this.barChartData.push(y);
                

              }
            }
          }
     
                   this.isShowchart=true;
  }
    getData(){
       this.barChartData=[];
         this.barChartOptions= {
    responsive: true,
  };
  this.barChartLabels=[];
  this.barChartLegend = true;
  this.barChartPlugins = [];
      debugger;
       var req={
      "startDate":new Date(this.startDate.year,this.startDate.month,this.startDate.day).toLocaleDateString(),
      "endDate":new Date(this.endDate.year,this.endDate.month,this.endDate.day).toLocaleDateString()
    };
                  this.service.getReportData(req).subscribe(res => {
                    this.actualRes=res;
                    console.log(res);
                 var list=   res.map(item => item.questionId)
  .filter((value, index, self) => self.indexOf(value) === index);
 var groupNamelist = res.map(item => item.groupName)
  .filter((value, index, self) => self.indexOf(value) === index);
  this.barChartLabels=groupNamelist.sort((n1,n2) => n1 - n2);
  this.labelList=groupNamelist.sort((n1,n2) => n1 - n2);;
  this.totalLabelList=list.sort((n1,n2) => n1 - n2);
 var mixedData=[];
 var actualData=[];
 for (let k = 0; k < groupNamelist.length; k++) {
            for (let i = 0; i < this.totalLabelList.length; i++) {
              var primarycount=res.filter(x=>x.questionId==this.totalLabelList[i] && x.priorityLevel==1).length;
              var questioncount=res.filter(x=>x.questionId==this.totalLabelList[i]).length;
              var percentvalue=(primarycount/questioncount)*100;
              var groupName=res.filter(x=>x.questionId==this.totalLabelList[i])[0].groupName;
              var x:any={};
              x.label=this.totalLabelList[i];
              x.value=percentvalue;
              x.groupName=groupName;
             
              if(groupName==groupNamelist[k] && k==0){
                var y:any={};
                y.data=[percentvalue,"","",""];
                y.label="Question"+" "+ this.totalLabelList[i];
                                y.backgroundColor=this.getRandomColor();

                 this.barChartData.push(y);
                  mixedData.push(x);
                                actualData.push(percentvalue);

              }
               if(groupName==groupNamelist[k] && k==1){
                var y:any={};
                y.data=["",percentvalue,"",""];
                y.label="Question"+" "+ this.totalLabelList[i];
                                y.backgroundColor=this.getRandomColor();

                 this.barChartData.push(y);
                  mixedData.push(x);
                                actualData.push(percentvalue);

              }
               if(groupName==groupNamelist[k] && k==2){
                var y:any={};
                y.data=["","",percentvalue,""];
                y.label="Question"+" "+ this.totalLabelList[i];
               y.backgroundColor=this.getRandomColor();

                 this.barChartData.push(y);
                  mixedData.push(x);
                                actualData.push(percentvalue);

              }
               if(groupName==groupNamelist[k] && k==3){
                var y:any={};
                y.data=["","","",percentvalue];
                y.label="Question"+" "+ this.totalLabelList[i];
                y.backgroundColor=this.getRandomColor();
                 this.barChartData.push(y);
                  mixedData.push(x);
                                actualData.push(percentvalue);

              }
             
            }
          }
        
  
                   this.isShowchart=true;
                    this.totaldatalist=actualData;
                    this.mixiedDataele=mixedData;
                    });
    }
     public chartClicked(e:any):void {
       this.datalist=[];
      console.log(e.active[0]._index);
      var x=e.active[0]._index;
      var ccc=this.labelList[x]

      this.datalist=this.actualRes.filter(x=>x.questionId==ccc);
      this.isShowGrid=true;
    }
}
