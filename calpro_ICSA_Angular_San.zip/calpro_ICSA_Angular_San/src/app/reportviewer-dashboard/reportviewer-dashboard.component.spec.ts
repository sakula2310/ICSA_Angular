import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportviewerDashboardComponent } from './reportviewer-dashboard.component';

describe('ReportviewerDashboardComponent', () => {
  let component: ReportviewerDashboardComponent;
  let fixture: ComponentFixture<ReportviewerDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportviewerDashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportviewerDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
