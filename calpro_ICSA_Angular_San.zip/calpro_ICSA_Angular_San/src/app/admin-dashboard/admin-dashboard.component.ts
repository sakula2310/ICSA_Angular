import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../services/ICSA/login.service';
import { SharedService } from '../services/ICSA/shared.service';
declare let $: any;

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  lstUsers: any;
  page = 1;
  pageSize = 6;
  collectionSize = 0;
  lstFilteredUser: any;
  constructor(private shared: SharedService, private loginService: LoginService, private router: Router) { }

  ngOnInit(): void {
    this.shared.setTitle("Admin DashBoard");
    this.getUsers();
  }

  onSort(event) {

  }

  getUsers() {
    this.loginService.getAllUsers().subscribe(data => {
      this.lstUsers = data;
      this.collectionSize = data.length;
      this.refreshUsers();
    });
  }
  editUser(user) {
    this.router.navigate(['/addedituser', user.userId])

  }

  refreshUsers() {
    this.lstFilteredUser = this.lstUsers
      .map((user, i) => ({ id: i + 1, ...user }))
      .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }


}
