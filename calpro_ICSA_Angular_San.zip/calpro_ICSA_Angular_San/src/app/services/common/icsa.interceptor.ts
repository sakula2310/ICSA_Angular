import { tap } from "rxjs/operators";
import { Injectable } from "@angular/core";
import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpResponse,
    HttpErrorResponse,
    HttpEventType
} from "@angular/common/http";
import { NgxSpinnerService } from "ngx-spinner";
import { Observable } from "rxjs";


@Injectable()
export class IcsaInterceptor implements HttpInterceptor {
    couter = 0;
    private totalRequests = 0;


    constructor(private spinner: NgxSpinnerService) { }

    intercept(
        req: HttpRequest<any>,
        next: HttpHandler
    ): Observable<HttpEvent<any>> {
        // start our loader here
        this.spinner.show();
        this.totalRequests++;
        return new Observable(observer => {
            let isCanceled = true;
            const sub = next
                .handle(req)
                .pipe(
                    tap(
                        (rsp: HttpResponse<any>) => {
                            if (rsp.type === HttpEventType.Response) {
                                isCanceled = false;
                                this.decreaseRequests();
                            }
                        },
                        (rspError: HttpErrorResponse) => {
                            isCanceled = false;
                            this.decreaseRequests();
                        }
                    )
                )
                .subscribe(observer);
            return () => {
                if (isCanceled) {
                    this.decreaseRequests();
                    sub.unsubscribe();
                }
            };
        });
    }
    private decreaseRequests() {
        this.totalRequests--;
        if (this.totalRequests === 0) {
            this.spinner.hide();
        }
    }
}
