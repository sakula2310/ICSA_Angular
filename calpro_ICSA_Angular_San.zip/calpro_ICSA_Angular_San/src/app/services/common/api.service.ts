import { Injectable } from "@angular/core";
import { environment } from "../../../environments/environment";
import { HttpHeaders, HttpClient, HttpParams } from "@angular/common/http";
import { Observable, throwError } from "rxjs";

import { catchError } from "rxjs/operators";
import { HttpRequest } from "@angular/common/http";
import { map } from "rxjs/operators";
import { tap } from "rxjs/operators";

@Injectable({
  providedIn: "root"
})
export class ApiService {
  constructor(private http: HttpClient) {}
  private serviceUrl: string = environment.ICSAUrl;
  private formatErrors(error: any) {
    return throwError(error.error);
  }

  get(path: string, params: HttpParams = new HttpParams()): Observable<any> {
    return this.http
      .get(this.serviceUrl + path, { params })
      .pipe(catchError(this.formatErrors));
  }
  getplainText(path: string, params: HttpParams = new HttpParams()) {
    return this.http
      .get(this.serviceUrl + path, { responseType: "text" })
      .pipe(catchError(this.formatErrors));
  }
  put(path: string, body: Object = {}): Observable<any> {
    return this.http
      .put(this.serviceUrl + path, JSON.stringify(body))
      .pipe(catchError(this.formatErrors));
  }

  post(path: string, body: Object = {}): Observable<any> {
    return this.http
      .post(this.serviceUrl + path, body)
      .pipe(catchError(this.formatErrors));
  }
  post1(path: string, body: Object = {}): Observable<any> {
    let loading = false;
    return this.http.post(this.serviceUrl + path, body).pipe(
      map(response => response),
      tap(() => (loading = false))
    );
  }
  postDecrypt(path: string, body: any): Observable<any> {
    console.log(JSON.stringify(body));
    return this.http
      .post(this.serviceUrl + path,JSON.stringify(body),
        {headers: new HttpHeaders().set("Content-Type", "application/json")})
      .pipe(catchError(this.formatErrors));
  }
  delete(path): Observable<any> {
    return this.http
      .delete(this.serviceUrl + path)
      .pipe(catchError(this.formatErrors));
  }
  deleteObj(path, bodyObj: Object = {}): Observable<any> {
    const options = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      }),
      body: bodyObj
    };
    return this.http
      .delete(this.serviceUrl + path, options)
      .pipe(catchError(this.formatErrors));
  }
  genaratePdf(url, postdata) {
    return this.http
      .post(this.serviceUrl + url, postdata, {
        responseType: "blob",
        observe: "response"
      })
      .toPromise();
  }
  // This method is called in case of a PUT request where Accrual service is directly invoked
  PostReturnText(url: string, postdata: string) {
    return this.http
      .post(this.serviceUrl + url, postdata, {
        headers: new HttpHeaders().set("Content-Type", "application/json"),
        responseType: "text"
      })
      .toPromise();
  }

  PutReturnText(url: string, postdata: string) {
    return this.http
      .put(this.serviceUrl + url, postdata, {
        headers: new HttpHeaders().set("Content-Type", "application/json"),
        responseType: "text"
      })
      .toPromise();
  }
  getStatic(
    path: string,
    params: HttpParams = new HttpParams()
  ): Observable<any> {
    return this.http.get(path, { params }).pipe(catchError(this.formatErrors));
  }

  post2(path: string, body: Object = {}): Observable<any> {
    return this.http
      .post(path, body)
      .pipe(catchError(this.formatErrors));
  }
}
