import { Injectable, Injector } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class ICSASpinnerService {
  isShow: boolean;
  loaderVisablity: Subject<boolean> = new Subject<boolean>();
  constructor() {
    this.loaderVisablity.subscribe((value) => {
      this.isShow = value;
  });
  }
  show() {
    this.loaderVisablity.next(true);
  }
  hide() {
    this.loaderVisablity.next(false);
  }
}
