import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";

@Injectable()
export class StorageService extends BehaviorSubject<any> {
 
  private _currentAssessment=[];
 
public currentUserSubject: BehaviorSubject<any>;
  public currentUser: Observable<any>;
    constructor() {
      super("");
    }
    
  setCurrentAssessment(val){
      this._currentAssessment=val;
   }
   getCurrentAssessment(){
      return this._currentAssessment;
    }
    
}