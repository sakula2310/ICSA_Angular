import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/Operators';
import { QuestionResponse } from 'src/app/shared/data/QuestionResponse';
import { ApiService } from '../common/api.service';
import { ApiDictionary } from './api-dictionary';

@Injectable()
export class CompetencyService extends BehaviorSubject<any> {



public currentUserSubject: BehaviorSubject<any>;
  public currentUser: Observable<any>;
    constructor(private apiService: ApiService) {
      super("");
      this.currentUserSubject = new BehaviorSubject<any>(JSON.parse(localStorage.getItem('currentUser')));
      this.currentUser = this.currentUserSubject.asObservable();
    }
  public get currentUserValue(): any {
    return this.currentUserSubject.value;
  }
  getQuestionsByCompetencyType(type: string) {
    return this.apiService
      .get(ApiDictionary.getQuestionsByCompetencyType.url+"?competencyType="+ type)
      .pipe(map(res => {
        return res.result;
      }));
  }
  getAllCompetencyQuestions() {
    return this.apiService
      .get(ApiDictionary.getAllCompetencyQuestions.url)
      .pipe(map(res => {
        return res.result;
      }));
  }
  saveAssessmentByCompetencyId(request: any) {
    return this.apiService
      .post(ApiDictionary.saveAssessmentByCompetencyId.url,request)
      .pipe(map(res => {
        return res.result;
      }));
  }
  saveAssessment(request: any) {
    return this.apiService
      .post(ApiDictionary.saveAssessment.url,request)
      .pipe(map(res => {
        return res.result;
      }));
  }

  getQuestionResponseById(competencyType: string, assessmentId: number, userId: number) {
    competencyType =(competencyType =="CompletAssessment")?"":competencyType;
    return this.apiService
      .get(ApiDictionary.getQuestionResponseById.url+"/"+userId+"/"+assessmentId+"?cometencyType="+competencyType)
      .pipe(map(res => {
        return res.result;
      }));
  }

  GetUserAssesmentsbyUser(userId: number) {
    return this.apiService
      .get(ApiDictionary.GetUserAssesmentsbyUser.url+"/"+userId)
      .pipe(map(res => {
        return res.result;
      }));
  }
  getAssessmentStatusbyAssessmentId(assessmentId: number, userId: number) {
    return this.apiService
      .get(ApiDictionary.getAssessmentStatusbyAssessmentId.url+"/"+userId+"/"+assessmentId)
      .pipe(map(res => {
        return res.result;
      }));
  }
  getPrioritizeLevel(userId: number, assessmentId: number) {
    return this.apiService
      .get(ApiDictionary.getPrioritizeLevel.url+"/"+userId+"/"+assessmentId)
      .pipe(map(res => {
        return res.result;
      }));
  }

   savePrioritizeLevel(reqItem: any) {
    return this.apiService
      .post(ApiDictionary.savePrioritizeLevel.url,reqItem)
      .pipe(map(res => {
        return res.result;
      }));
  }

  GetAssessmentResponse(userId: number,assessmentId: number,) {
    debugger;
    return this.apiService
      .get(ApiDictionary.GetAssessmentResponse.url+"/"+userId+"/"+assessmentId)
      .pipe(map(res => {
        return res.result;
      }));
  }

  GetTopFiveAssessmentResponse(userId: number,assessmentId: number,) {
    return this.apiService
      .get(ApiDictionary.GetTopFiveAssessmentResponse.url+"/"+userId+"/"+assessmentId)
      .pipe(map(res => {
        return res.result;
      }));
  }
  GetTopFiveProfessionalDevelopmentResourcePlans(userId: number,assessmentId: number,) {
    return this.apiService
      .get(ApiDictionary.GetTopFiveProfessionalDevelopmentResourcePlans.url+"/"+userId+"/"+assessmentId)
      .pipe(map(res => {
        return res.result;
      }));
  }
  GetPDResponse(questionId: number,rank: number,) {
    return this.apiService
      .get(ApiDictionary.GetPDResponse.url+"/"+questionId+"/"+rank)
      .pipe(map(res => {
        return res.result;
      }));
  }

}
