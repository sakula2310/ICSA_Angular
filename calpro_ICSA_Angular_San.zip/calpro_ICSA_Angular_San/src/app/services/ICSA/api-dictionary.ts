export const ApiDictionary = {
  login: {
    url: "Login"
  },
  reportData: {
    url: "GetReportData"
  },
  userAvailability: {
    url: "UserAvailability"
  },
  register: {
    url: "Register"
  },
  getAgencies: {
    url: "getAgencies"
  },
  getRoles: {
    url: "GetRoles"
  },
  getAllUsers: {
    url: "GetAllUsers"
  },
  getQuestionsByCompetencyType: {
    url:"GetQuestionsByCompetencyType"
  },
  getAllCompetencyQuestions:{
    url:"GetAllQuestions"
  },
  saveAssessmentByCompetencyId: {
    url:"SaveCometencyAssessment"
  },
  saveAssessment: {
    url: "SaveAssessment"
  },
  getQuestionResponseById: {
    url: "GetAssessmentResponse"
  },
  getUserInfoByUserId: {
    url: "GetUserInfoByUserId"
  },
  getAgenciesByUserId: {
    url: "GetAgenciesByUserId"
  },
  UpdateUserDetails: {
    url: "UpdateUser"
  },
  GetUserAssesmentsbyUser: {
    url: "GetUserAssessments"
  },
  getAssessmentStatusbyAssessmentId: {
    url:"GetAssessmentStatusbyAssessmentId"
  },
  getPrioritizeLevel: {
    url: "GetPrioritizeCompetency"
  },
  GetAssessmentResponse: {
    url: "GetTotalAssessmentResponse"
  },
  GetTopFiveAssessmentResponse: {
    url: "GetTopFiveAssessmentResponse"
  },
  savePrioritizeLevel: {
    url:"ResetUserCompetencyPriority"
  },
   SaveUserAgencies: {
    url: "SaveUserAgencies"
  },
  GetTopFiveProfessionalDevelopmentResourcePlans: {
    url: "GetTopFiveProfessionalDevelopmentResourcePlans"
  } ,
  GetPDResponse: {
    url: "GetPDResponse"
  }
};
