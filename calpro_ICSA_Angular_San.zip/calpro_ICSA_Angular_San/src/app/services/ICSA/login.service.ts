import { EventEmitter, Injectable, Output } from "@angular/core";
import { Observable } from "rxjs";
import { map } from "rxjs/Operators";
import { ApiService } from "../common/api.service";
import { ApiDictionary } from "./api-dictionary";
import { BehaviorSubject } from "rxjs";
import { retry } from 'rxjs/operators';
import { User } from "src/app/shared/data/UserData";
import { Assesment } from "src/app/shared/data/AssesmentData";

@Injectable()
export class LoginService extends BehaviorSubject<any> {

  @Output() fire: EventEmitter<any> = new EventEmitter();
  public currentUserSubject: BehaviorSubject<any>;
  public currentUser: Observable<any>;
  constructor(private apiService: ApiService) {
    super("");
    this.currentUserSubject = new BehaviorSubject<any>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
  }
  public get currentUserValue(): any {
    return this.currentUserSubject.value;
  }
   change(val) {
    console.log('change started'); 
     this.fire.emit(val);
   }

   getEmittedValue() {
     return this.currentUserSubject.value;
   }
  login(request: any) {
    return this.apiService
      .post(ApiDictionary.login.url + "?emailId=" + request.emailId + "&password=" + request.password, "")
      .pipe(map(user => {
        // login successful if there's a jwt token in the response
        if (user && user.result.userId > 0) {
          // store user details and jwt token in local storage to keep user logged in between page refreshes
          localStorage.setItem('currentUser', JSON.stringify(user.result));
          this.currentUserSubject.next(user.result);
        }
        return user;
      }));
  }
  userAvailability(userEmail: string) {
    return this.apiService
      .get(ApiDictionary.userAvailability.url + "/" + userEmail)
      .pipe(map(user => {
        return user;
      }));
  }
  register(user: User) {
    return this.apiService
      .post(ApiDictionary.register.url, user)
      .pipe(map(user => {
        console.log(user);
        return user;
        // if (user && user.result.userId > 0) {
        //   // store user details and jwt token in local storage to keep user logged in between page refreshes
        //   localStorage.setItem('currentUser', JSON.stringify(user.result));
        //   this.currentUserSubject.next(user.result);
        // }
        // return user;
      }));
  }

  getRoles() {
    return this.apiService
      .get(ApiDictionary.getRoles.url)
      .pipe(map(roles => {
        return roles.result;
      }));
  }
  getAllUsers() {
    return this.apiService
      .get(ApiDictionary.getAllUsers.url)
      .pipe(map(roles => {
        return roles.result;
      }));
  }

  getUserInfoByUserId(userId) {
    return this.apiService
      .get(ApiDictionary.getUserInfoByUserId.url + "/" + userId)
      .pipe(map(user => {
        return user;
      }));
  }
  getAgenciesByUserId(userId) {
    return this.apiService
      .get(ApiDictionary.getAgenciesByUserId.url + "/" + userId)
      .pipe(map(user => {
        return user;
      }));
  }

  updateUserDetails(user: User) {
    return this.apiService
      .post(ApiDictionary.UpdateUserDetails.url, user)
      .pipe(map(data => {
        console.log(data);
        return data.result;
      }));
  }
  saveUserAgencies(assesment: any) {
    return this.apiService
      .post(ApiDictionary.SaveUserAgencies.url, assesment)
      .pipe(map(data => {
        console.log(data);
        return data.result;
      }));
  }
}
