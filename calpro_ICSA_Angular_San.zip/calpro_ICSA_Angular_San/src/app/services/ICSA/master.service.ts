import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { map } from "rxjs/Operators";
import { ApiService } from "../common/api.service";
import { ApiDictionary } from "./api-dictionary";
import { BehaviorSubject } from "rxjs";
import { retry } from 'rxjs/operators';
import { User } from "src/app/shared/data/UserData";

@Injectable()
export class MasterService extends BehaviorSubject<any> {
 
    constructor(private apiService: ApiService) {
        super("");
    }
    getAgencies() {
        return this.apiService
            .get(ApiDictionary.getAgencies.url)
            .pipe(map(agency => {
                // login successful if there's a jwt token in the response
                if (agency && agency.result.length > 0) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
         
                }
                return agency.result;
            }));
    }
}