import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { map } from "rxjs/Operators";
import { ApiService } from "../common/api.service";
import { ApiDictionary } from "./api-dictionary";
import { BehaviorSubject } from "rxjs";
import { retry } from 'rxjs/operators';

@Injectable()
export class ReportService extends BehaviorSubject<any> {
  constructor(private apiService: ApiService) {
    super("");
  }
   getReportData(request: any) {
    return this.apiService
      .post(ApiDictionary.reportData.url+"?startDate="+request.startDate+"&endDate="+request.endDate)
      .pipe(map(data => data));
  }
}
