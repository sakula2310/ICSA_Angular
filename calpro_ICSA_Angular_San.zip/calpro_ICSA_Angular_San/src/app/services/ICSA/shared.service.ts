import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { map } from "rxjs/Operators";
import { ApiService } from "../common/api.service";
import { ApiDictionary } from "./api-dictionary";
import { BehaviorSubject } from "rxjs";
import { retry } from 'rxjs/operators';
import { User } from "src/app/shared/data/UserData";
import { FindValueSubscriber } from "rxjs/internal/operators/find";

@Injectable()
export class SharedService {
  private defaultTitle = 'CALPRO Login';
  private defaultEnableMenuOptions = false;
  private titleSubject: BehaviorSubject<string> = new BehaviorSubject(this.defaultTitle);
  private isMenuVisibleSubject: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private isEnableMenuOptionsSubject: BehaviorSubject<boolean> = new BehaviorSubject(this.defaultEnableMenuOptions);

  public title: Observable<string>;
  public isMenuVisible: Observable<boolean>;
  public isEnableMenuOptions: Observable<boolean>;

  constructor() {
    this.title = this.titleSubject.asObservable();
    this.isMenuVisible = this.isMenuVisibleSubject.asObservable();
    this.isEnableMenuOptions = this.isEnableMenuOptionsSubject.asObservable();
  }

  public setTitle(title: string) {
    this.titleSubject.next(title);
  }
  public setMenuVisibility(value: boolean) {
    this.isMenuVisibleSubject.next(value);
  }
  public enableMenuOptions(value: boolean) {
    this.isEnableMenuOptionsSubject.next(value);
  }
}
